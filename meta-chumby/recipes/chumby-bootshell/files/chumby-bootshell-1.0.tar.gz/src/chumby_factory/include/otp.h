#ifndef __OTP_H__
#define __OTP_H__

int otp_write(int address, int data);
int otp_open_read();
int otp_close_read();


#endif //__OTP_H__
