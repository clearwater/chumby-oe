#include <shell.h>
#include <utils.h>

#define HW_APBX_CTRL0            (*((volatile int *)0x80024000))
#define HW_APBX_CTRL2            (*((volatile int *)0x80024020))
#define HW_APBX_CTRL2_SET        (*((volatile int *)0x80024024))
#define HW_APBX_CTRL2_CLR        (*((volatile int *)0x80024028))
#define HW_APBX_CHANNEL_CTRL     (*((volatile int *)0x80024030))
#define HW_APBX_CHANNEL_CTRL_SET (*((volatile int *)0x80024034))
#define HW_APBX_CH3_NXTCMDAR     (*((volatile int *)0x80024260))
#define HW_APBX_CH3_SEMA         (*((volatile int *)0x80024290))
#define HW_I2C_CTRL0             (*((volatile int *)0x80058000))
#define HW_I2C_CTRL0_SET         (*((volatile int *)0x80058004))
#define HW_I2C_CTRL0_CLR         (*((volatile int *)0x80058008))
#define HW_I2C_CTRL1             (*((volatile int *)0x80058040))
#define HW_I2C_CTRL1_SET         (*((volatile int *)0x80058044))
#define HW_I2C_CTRL1_CLR         (*((volatile int *)0x80058048))
#define HW_PINCTRL_MUXSEL1_CLR   (*((volatile int *)0x80018118))

#define I2C_DMA_CHANNEL 3

struct mx233_dma {
	struct mx233_dma *next_cmd_addr;
	// Configuration format:
	// ################PPPPrrrrWDrrINCC
	// # = Number of bytes to transfer
	// P = Number of PIO words to write
	// r = reserved
	// W = Wait-4-endcmd
	// D = Decrement semaphore
	// I = IRQ complete
	// N = chain
	// C = command
	unsigned int      configuration;

	unsigned char    *buffer;

	// These values will get written to the registers after DMA has
	// completed.  A handy way to start transfers.
	// Because it goes in the order documented, the first byte written here
	// will fill in HW_I2C_CTRL0.
	unsigned long     pio_values[16];
} __attribute__((__packed__));

/* CMD is 0-1 */
#define CMD_CHAIN       (1<<2)
#define CMD_IRQCOMPLETE (1<<3)
#define CMD_SEMAPHORE   (1<<6)
#define CMD_WAIT4END    (1<<7)
/* PIO words are 12-15 */


static int reset_apbx_channel(int channel) {
	int reset_mask = (1<<channel)<<16;
	int i;

	// Reset the APBX block.
	HW_APBX_CTRL0=0x00000000;

	// Reset the I2C channel.
	HW_APBX_CHANNEL_CTRL_SET=reset_mask;
	for(i=0; i<1000; i++) {
		if(!(HW_APBX_CHANNEL_CTRL & reset_mask)) {
			return 0;
		}
		msleep(1);
	}
	return 1;
}

#define EARLY_TERM_IRQ (1<<3)
#define NO_SLAVE_ACK_IRQ (1<<5)
#define MASTER_LOSS_IRQ (1<<2)
// Read one byte from the offset in the EEPROM located at offset /addr/.
unsigned int eeprom_read(unsigned char addr, unsigned short offset) {
	struct mx233_dma set_address;
	struct mx233_dma get_value;
	struct mx233_dma get_data;
	unsigned char write_cmd[4];
	unsigned char read_cmd[4];
	int value;
	int i;


	if(HW_I2C_CTRL0 & 0xc0000000) {

		// Set the I2C pins to not be GPIOs.
		HW_PINCTRL_MUXSEL1_CLR=0xf0000000;

		// And bring it back out.
		HW_I2C_CTRL0_CLR=0xc0000000;

		if(reset_apbx_channel(I2C_DMA_CHANNEL)) {
			STR("Timeout while resetting I2C DMA channel\n");
			return 0;
		}
	}

	// Work around Chip Errata #2727: 9th clock pulse not generated.
	HW_I2C_CTRL1_SET=0x08000000;

	// Mask off the last bit, which is the read/write bit in I2C.
	addr &= 0xfe;

	// Set up the "opening" packet that we send to get the correct register.
	write_cmd[0] = addr;
	write_cmd[1] = offset>>8;
	write_cmd[2] = offset&0xff;
	set_address.buffer        = write_cmd;
	set_address.next_cmd_addr = &get_value;
	set_address.configuration = (3<<16) | (1<<12) | CMD_CHAIN | CMD_WAIT4END | 2;
	set_address.pio_values[0] = (1<<19) | (1<<17) | (1<<16) | 3;

	// Send the "OK to read" message.
	read_cmd[0] = addr+1;
	get_value.buffer        = read_cmd;
	get_value.next_cmd_addr = &get_data;
	get_value.configuration = (1<<16) | (1<<12) | CMD_CHAIN | CMD_WAIT4END | 2;
	get_value.pio_values[0] = (1<<21) | (1<<19) | (1<<17) | (1<<16) | 1;

	// Read the value.
	memset(&value, 0, sizeof(value));
	get_data.buffer        = (unsigned char *)&value;
	get_data.next_cmd_addr = 0;
	get_data.configuration = (4<<16) | (1<<12) | CMD_SEMAPHORE | CMD_WAIT4END | 1;
	get_data.pio_values[0] = (1<<20) | (1<<17) | (1<<25) | 1;


	/*
	STR("The three commands are at addresses "),
		HEX(&set_address), STR(", "),
		HEX(&get_value), STR(", and "),
		HEX(&get_data), STR(".\n");
	*/

	// Configure the DMA channel.
	HW_APBX_CH3_NXTCMDAR = (int)(&set_address);

	// Disable IRQ-on-complete.
	HW_APBX_CTRL2_CLR    = (1<<3);

	// Start the DMA transfer by incrementing the semaphore.
	HW_APBX_CH3_SEMA=0x00000001;

	// Wait for it to complete.
	for(i=0; i<1000; i++) {
		if(HW_I2C_CTRL1 & MASTER_LOSS_IRQ) {
			STR("MASTER_LOSS_IRQ was set\n");
			return 0;
		}
		if(HW_I2C_CTRL1 & NO_SLAVE_ACK_IRQ) {
			STR("NO_SLAVE_ACK_IRQ was set\n");
			return 0;
		}
		if(HW_I2C_CTRL1 & EARLY_TERM_IRQ) {
			STR("EARLY_TERM_IRQ was set\n");
			return 0;
		}
		if(!(HW_APBX_CH3_SEMA & 0x00ff0000)) {
			return value;
		}
		msleep(1);
	}
	STR("Timed out\n");
	return 0;
}
