#ifndef __SD_H__
#define __SD_H__

#include "serial.h"

typedef struct rom_BootInit {
    long *pMem;
    int size;
    int mode;
} rom_BootInit_t;

typedef unsigned char chunk_t[16];
#define PMEM_SIZE 0x138c

int sd_init_rev2(rom_BootInit_t *pInit);
chunk_t *sd_next_rev2(int *pCount);
int sd_skip_rev2(int count);
int sd_stop_rev2(void);


int sd_init_rev3(rom_BootInit_t *pInit);
chunk_t *sd_next_rev3(int *pCount);
int sd_skip_rev3(int count);
int sd_stop_rev3(void);


int sd_init_rev4(rom_BootInit_t *pInit);
chunk_t *sd_next_rev4(int *pCount);
int sd_skip_rev4(int count);
int sd_stop_rev4(void);


int sd_ctrl(int action, void *pArg);



static inline void print_serial_error(void) {
	serial_puts("Unrecognized CPU rev.  New die?  Need to patch bootloader.\n");
}

#define HW_DIGCTL_CHIPID (*((volatile int *)0x8001c310))
static inline int sd_init(rom_BootInit_t *pInit) {
	int rev = HW_DIGCTL_CHIPID & 0xff;
	if(rev == 2)
		return sd_init_rev2(pInit);
	if(rev == 3)
		return sd_init_rev3(pInit);
	if(rev == 4)
		return sd_init_rev4(pInit);
	print_serial_error();
	return 0;
}

static inline chunk_t *sd_next(int *pCount) {
	int rev = HW_DIGCTL_CHIPID & 0xff;
	if(rev == 2)
		return sd_next_rev2(pCount);
	if(rev == 3)
		return sd_next_rev3(pCount);
	if(rev == 4)
		return sd_next_rev4(pCount);
	print_serial_error();
	return 0;
}

static inline int sd_skip(int count) {
	int rev = HW_DIGCTL_CHIPID & 0xff;
	if(rev == 2)
		return sd_skip_rev2(count);
	if(rev == 3)
		return sd_skip_rev3(count);
	if(rev == 4)
		return sd_skip_rev4(count);
	print_serial_error();
	return 0;
}

static inline int sd_stop(void) {
	int rev = HW_DIGCTL_CHIPID & 0xff;
	if(rev == 2)
		return sd_stop_rev2();
	if(rev == 3)
		return sd_stop_rev3();
	if(rev == 4)
		return sd_stop_rev4();
	print_serial_error();
	return 0;
}

#endif //__SD_H__
