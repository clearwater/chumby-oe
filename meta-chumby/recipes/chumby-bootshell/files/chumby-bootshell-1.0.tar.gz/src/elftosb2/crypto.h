/*
 * File:	crypto.h
 *
 * Copyright (c) SigmaTel, Inc. All rights reserved.
 *
 * SigmaTel, Inc.
 * Proprietary & Confidential
 *
 * This source code and the algorithms implemented therein constitute
 * confidential information and may comprise trade secrets of SigmaTel, Inc.
 * or its associates, and any use thereof is subject to the terms and
 * conditions of the Confidential Disclosure Agreement pursual to which this
 * source code was originally received.
 */
#ifndef __CRYPTO_H
#define __CRYPTO_H

#include "stdafx.h"

#define OLD_CRYPTO 0	//!< Set to 1 to use original crypto algorithm.

#define KEY_TABLE_NUM_WORDS 256
#define KEY_NUM_WORDS       16
#define CODING_NORMAL 

typedef uint32_t key_t_sgtl[KEY_NUM_WORDS];

typedef struct
{
  key_t_sgtl auth_key;
  key_t_sgtl crypt_key;
} key_set_t;

#ifdef __cplusplus
extern "C"
{
#endif

#if OLD_CRYPTO

void CRYPTO_TransformKeySet(uint32_t modifier, uint32_t number_steps, key_set_t* master_key_set, key_set_t* transformed_key_set);

//returns an encrypted signature, and encrypts the block pointed to
uint32_t CRYPTO_EncryptBlock(key_set_t*pKeys, uint32_t *pBlock, uint16_t u16PayloadLength);

//pass that returned encrypted signature back to decrypt and authenticate 
//returns true/false (and clears out the block if it doesn�t authenticate)
bool CRYPTO_DecryptAndAuthenticateBlock(key_set_t*pKeys, uint32_t *pBlock, uint16_t u16PayloadLength, uint32_t u32Signature);

//decrypts a block but doesn't worry about authentication
void CRYPTO_DecryptBlock(key_set_t*pKeys, uint32_t *pBlock, uint16_t u16PayloadLength);

#else //OLD_CRYPTO

void CRYPTO_Transform_Key_Set(uint32_t u32ModifierValue, uint32_t number_steps, key_set_t *pOriginal, key_set_t *pKeys);

//returns an encrypted signature, and encrypts the block pointed to
uint32_t CRYPTO_EncryptBlock(key_set_t*pKeys, uint32_t *pBlock, uint32_t u32PayloadLength);

//pass that returned encrypted signature back to decrypt and authenticate
//returns true/false (and clears out the block if it doesn�t authenticate)
bool CRYPTO_DecryptAndAuthenticateBlock(key_set_t*pKeys, uint32_t *pBlock, uint32_t u32PayloadLength, uint32_t u32Signature);

// steps the pseudo random number generator
void CRYPTO_Step(uint32_t number_steps, uint32_t * pu32);

#endif // OLD_CRYPTO

#ifdef __cplusplus
}
#endif

#endif //__CRYPTO_H
