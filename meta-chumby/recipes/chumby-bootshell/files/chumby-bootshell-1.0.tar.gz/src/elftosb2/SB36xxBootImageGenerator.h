/*
 * File:	SB36xxBootImageGenerator.h
 *
 * Copyright (c) SigmaTel, Inc. All rights reserved.
 *
 * SigmaTel, Inc.
 * Proprietary & Confidential
 *
 * This source code and the algorithms implemented therein constitute
 * confidential information and may comprise trade secrets of SigmaTel, Inc.
 * or its associates, and any use thereof is subject to the terms and
 * conditions of the Confidential Disclosure Agreement pursual to which this
 * source code was originally received.
 */
#if !defined(_SB36xxBootImageGenerator_h_)
#define _SB36xxBootImageGenerator_h_

#include "BootImageGenerator.h"
#include "St3600IPL.h"

namespace elftosb
{

/*!
 * \brief Generator for STMP36xx boot images.
 *
 * The first command section is used to generate the boot commands. If there
 * are any other command sections, warnings will be printed. Similarly, the
 * first binary data section is used for the user data that is appended to
 * the end of the output .sb file. Warnings are printed for additional data
 * sections.
 */
class SB36xxBootImageGenerator : public BootImageGenerator
{
public:
	//! \brief Default constructor.
	SB36xxBootImageGenerator() : BootImageGenerator(), m_enableSections(false) {}
	
	//! \brief Builds the resulting boot image from previously added output sections.
	virtual BootImage * generate();
	
protected:
	bool m_enableSections;
	
	void processOptions(St3600IPL * image);
	
	void processOperationSection(OperationSequenceSection * section, St3600IPL * image);
	void processDataSection(BinaryDataSection * section, St3600IPL * image);

	void processLoadOperation(LoadOperation * op, St3600IPL * image);
	void processExecuteOperation(ExecuteOperation * op, St3600IPL * image);
	void processBootModeOperation(BootModeOperation * op, St3600IPL * image);
};

}; // namespace elftosb

#endif // _SB36xxBootImageGenerator_h_

