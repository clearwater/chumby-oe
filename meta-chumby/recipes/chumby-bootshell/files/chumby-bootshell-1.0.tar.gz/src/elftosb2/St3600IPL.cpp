/*
 * File:	St3600IPL.cpp
 *
 * Copyright (c) SigmaTel, Inc. All rights reserved.
 *
 * SigmaTel, Inc.
 * Proprietary & Confidential
 *
 * This source code and the algorithms implemented therein constitute
 * confidential information and may comprise trade secrets of SigmaTel, Inc.
 * or its associates, and any use thereof is subject to the terms and
 * conditions of the Confidential Disclosure Agreement pursual to which this
 * source code was originally received.
 */

#include "St3600IPL.h"
#include "StEncrypter.h"
#include <stdexcept>
#include <cstring>
#include "Logging.h"

//! The entries in this table are the size of the SDRAM in megabytes. The
//! last entry must be 0.
const uint16_t k_sdram_size_table[] = { 2, 8, 16, 32, 64, 0 };

//! Initializes the encryption key and authentication signature both to 0.
//! The product and component version numbers are set to "999.999.999".
St3600IPL::St3600IPL()
:	m_romVersion(0),
    m_driveTag(0),
	m_keyTransform(0),
	m_encrypter(0),
	m_userData(0),
	m_userDataLength(0),
    m_userDataAlignment(1)
{
	// set default product version
	m_productVersion.m_major = IPL_DEFAULT_VERSION_NUMBER;
    m_productVersion.m_pad0 = 0;
	m_productVersion.m_minor = IPL_DEFAULT_VERSION_NUMBER;
    m_productVersion.m_pad1 = 0;
	m_productVersion.m_revision = IPL_DEFAULT_VERSION_NUMBER;
    m_productVersion.m_pad2 = 0;
	
	// set default component version
	m_componentVersion.m_major = IPL_DEFAULT_VERSION_NUMBER;
    m_componentVersion.m_pad0 = 0;
	m_componentVersion.m_minor = IPL_DEFAULT_VERSION_NUMBER;
    m_componentVersion.m_pad1 = 0;
	m_componentVersion.m_revision = IPL_DEFAULT_VERSION_NUMBER;
    m_componentVersion.m_pad2 = 0;
	
	m_firstNonCriticalEntry = m_layout.end();
}

//! Frees any memory allocated as part of the layout entries.
St3600IPL::~St3600IPL()
{
	// dispose of command data
	LayoutEntryList::iterator it;
	for (it = m_layout.begin(); it != m_layout.end(); ++it)
	{
		LayoutEntry & theEntry = *it;
		if (theEntry.m_data)
		{
			delete [] theEntry.m_data;
			theEntry.m_data = NULL;
		}
	}
}

//! \brief Converts a host endian BCD value to the equivalent big-endian BCD.
//!
//! The output is a half-word. And BCD is inherently big-endian, or byte ordered, if
//! you prefer to think of it that way. So for little endian systems, we need to convert
//! the output half-word in reverse byte order. When it is written to disk or a
//! buffer it will come out big endian.
//!
//! For example:
//!     - The input is BCD in host endian format, so 0x1234. Written to a file, this would
//!       come out as 0x34 0x12, reverse of what we want.
//!     - The desired BCD output is the two bytes 0x12 0x34.
//!     - So the function's uint16_t result must be 0x3412 on a little-endian host.
//!
//! On big endian hosts, we don't have to worry about byte swapping.
uint16_t St3600IPL::fixBCDByteOrder(unsigned hostEndianBCD)
{
    uint16_t result = hostEndianBCD;
    
#if defined(__LITTLE_ENDIAN__)
    // swap the bytes
    result = ((result & 0xff00) >> 8) | ((result & 0x00ff) << 8);
#endif
    
    return result;
}

void St3600IPL::setProductVersion(unsigned inMajor, unsigned inMinor, unsigned inRevision)
{
    m_productVersion.m_major = fixBCDByteOrder(inMajor);
	m_productVersion.m_minor = fixBCDByteOrder(inMinor);
	m_productVersion.m_revision = fixBCDByteOrder(inRevision);
}

void St3600IPL::setComponentVersion(unsigned inMajor, unsigned inMinor, unsigned inRevision)
{
	m_componentVersion.m_major = fixBCDByteOrder(inMajor);
	m_componentVersion.m_minor = fixBCDByteOrder(inMinor);
	m_componentVersion.m_revision = fixBCDByteOrder(inRevision);
}

//! Makes a copy of the \a inData. The argument values are assumed to be within their
//! respective ranges. The arguments are validated to make sure they will fit within
//! the alloted number of bits. If any arguments are out of range, an exception will
//! be thrown.
//!
//! Because of the peculiarities of the pattern fill command, it cannot be added with
//! this method. For that command, the \a byte_count field does not apply to the
//! data length, but the length of the memory fill. To add a pattern fill command, use
//! the #addPatternFillCommand() method instead.
//!
//! \exception std::bad_alloc may be thrown.
//! \exception std::out_of_range is thrown for out of range arguments.
void St3600IPL::addBootCommand(bool inCritical, unsigned inCommand, unsigned inDataType, uint32_t inAddress, const uint8_t * inData, unsigned inDataLength)
{
	// verify arguments
	if (inDataType > 0x2)
		throw std::out_of_range("out of range data_type");
	if (inCommand > 0xf)
		throw std::out_of_range("out of range boot_cmd");
	if (inDataLength > IPL_MAX_DATA_LENGTH)
		throw std::out_of_range("out of range byte_count");
	
	// fill out new entry
	LayoutEntry newEntry;
	newEntry.m_isCritical = inCritical;
	newEntry.m_commandLength = 1;
	newEntry.m_dataType = inDataType;
	newEntry.m_bootCommand = inCommand;
	newEntry.m_destinationAddress = inAddress;
	newEntry.m_byteCount = inDataLength;
	
	// make a copy of the data
	newEntry.m_data = new uint8_t[inDataLength];
	newEntry.m_dataLength = inDataLength;
	memcpy(newEntry.m_data, inData, inDataLength);
	
	// calculate total 32-bit words
	if (newEntry.m_dataLength != 0)
	{
		newEntry.m_commandLength += ((inDataLength - 1) / 4) + 1;
	}
	
	// add entry
	insertLayoutEntry(newEntry);
}

//! The \a inData buffer is copied during this call, so it can safely be disposed of after
//! the method returns.
//!
//! If the argument \a inDataLength is greater than 8180 then more than one command will
//! be added to load the data. Each command can only load a maximum of 8180 bytes.
void St3600IPL::addLoadDataBlockCommand(bool inCritical, uint32_t inAddress, const uint8_t * inData, unsigned inDataLength)
{
	// must break up oversized loads into multiple commands
	unsigned remaining = inDataLength;
	unsigned offset = 0;
	
	while (remaining)
	{
		const uint8_t * data = &inData[offset];
		unsigned length = remaining > IPL_MAX_DATA_LENGTH ? IPL_MAX_DATA_LENGTH : remaining;
		uint32_t address = inAddress + static_cast<uint32_t>(offset);
		
		addBootCommand(inCritical, LOAD_DATA_BLOCK_CMD, 0, address, data, length);
		
		remaining -= length;
		offset += length;
	}
}

//! The \a inPatternLength is in bytes. The pattern in \a inPattern should be in the least
//! significant bytes.
//!
//! If \a inPatternLength is greater than 16383 bytes then more than one pattern fill command
//! will be added to the layout. This is because each command can only fill a maximum of
//! 16376 bytes.
//!
//! \todo 2-byte patterns are required to be aligned. This is currently not enforced. It is
//!		also not handled correctly when breaking into multiple commands.
//! \note This method is probably not portable to big-endian architectures as it currently
//!		stands.
void St3600IPL::addPatternFillCommand(bool inCritical, uint32_t inAddress, unsigned inFillLength, unsigned inPattern, unsigned inPatternLength)
{
	int dataType;
	switch (inPatternLength)
	{
		case 1:	// 8-bit
			dataType = 0x2;
			break;
		case 2:	// 16-bit
			dataType = 0x1;
			break;
		case 4:	// 32-bit
		default:
			dataType = 0x0;
			break;
	}

	LayoutEntry newEntry;
	newEntry.m_isCritical = inCritical;
	newEntry.m_commandLength = 2;	// word 1=addr, word 2=pattern
	newEntry.m_dataType = dataType;
	newEntry.m_bootCommand = PATTERN_FILL_CMD;
	newEntry.m_dataLength = 0;
	
	// break oversized pattern fills into more than one command
	unsigned remaining = inFillLength;
	unsigned offset = 0;
	
	while (remaining)
	{
		unsigned length = remaining > IPL_MAX_BYTE_COUNT ? IPL_MAX_BYTE_COUNT : remaining;
		
		newEntry.m_destinationAddress = inAddress + static_cast<uint32_t>(offset);
		newEntry.m_byteCount = length;
		
		// allocate space for the pattern for each command we add!
		newEntry.m_data = new uint8_t[inPatternLength];
		memcpy(newEntry.m_data, &inPattern, inPatternLength);
		newEntry.m_dataLength = inPatternLength;
		
		// add entry
		insertLayoutEntry(newEntry);
		
		remaining -= length;
		offset += length;
	}
}
	
void St3600IPL::addJumpCommand(bool inCritical, uint32_t inAddress, uint32_t inArg)
{
	uint32_t arg = inArg;
	addBootCommand(inCritical, BOOTLOADING_COMPLETE_CMD, 0, inAddress, (const uint8_t *)&arg, sizeof(arg));
}

void St3600IPL::addJumpAndReturnCommand(bool inCritical, uint32_t inAddress, uint32_t inArg)
{
	uint32_t arg = inArg;
	addBootCommand(inCritical, JUMP_AND_RETURN_CMD, 0, inAddress, (const uint8_t *)&arg, sizeof(arg));
}

void St3600IPL::addSwitchDriverCommand(bool inCritical, uint32_t inFunctionTableAddress)
{
	addBootCommand(inCritical, SWITCH_DRIVER_CMD, 0, inFunctionTableAddress, NULL, 0);
}

//! The \a inChipEnable parameter must be between 0 and 3.
//!
//! The \a inSDRAMSize paramters is the actual size of the SDRAM in megabytes.
//! It must be a power of 2. This value is converted into an index into a
//! size table stored in the ROM. If the value passed in does not match any of
//! the table entries, an exception will be thrown.
void St3600IPL::addInitializeSDRAMCommand(bool inCritical, uint16_t inChipEnable, uint16_t inSDRAMSize)
{
    // check chip enable range
    if (inChipEnable > 3)
    {
        throw std::range_error("chip enable is out of range");
    }
    
	// convert inSDRAMSize into table index
	int sdramTableIndex=0;
	while (k_sdram_size_table[sdramTableIndex] != 0)
	{
		if (k_sdram_size_table[sdramTableIndex] == inSDRAMSize)
		{
			break;
		}
		++sdramTableIndex;
	}
	
	// make sure we found an entry
	if (k_sdram_size_table[sdramTableIndex] == 0)
	{
		throw std::runtime_error("no matching SDRAM table entry was found");
	}
	
	// add boot command
    uint32_t param = (sdramTableIndex << 16) | inChipEnable;
    addBootCommand(inCritical, INITIALIZE_SDRAM_CMD, 0, param, NULL, 0);
}

void St3600IPL::addEnableProgressCodesCommand(bool inCritical, int inVerbosity)
{
    addBootCommand(inCritical, ENABLE_PROGRESS_CODES_CMD, 0, inVerbosity, NULL, 0);
}

void St3600IPL::addSectionTagCommand(bool inCritical, uint32_t sectionName)
{
	if ((sectionName & ~0x3fff) != 0)
	{
		Log::log(Logger::WARNING, "warning: section name 0x%08x will be masked to 0x%04x!\n", sectionName, sectionName & 0x3fff);
	}
	
	LayoutEntry newEntry;
	newEntry.m_isCritical = inCritical;
	newEntry.m_commandLength = 1;
	newEntry.m_dataType = 0;
	newEntry.m_bootCommand = SECTION_TAG_CMD;
	newEntry.m_dataLength = 0;
	newEntry.m_byteCount = sectionName & 0x3fff;
	newEntry.m_destinationAddress = 0;
	newEntry.m_data = NULL;
	insertLayoutEntry(newEntry);
}

//! Using this method to add new layout command entries will ensure that
//! critical commands are always sorted before the non-critical ones.
void St3600IPL::insertLayoutEntry(LayoutEntry & inEntry)
{
	// insert new command
	if (inEntry.m_isCritical)
	{
		m_layout.insert(m_firstNonCriticalEntry, inEntry);
	}
	else
	{
		m_layout.push_back(inEntry);
	}
	
	// search for first non-critical command
	m_firstNonCriticalEntry = m_layout.begin();
	while (m_firstNonCriticalEntry != m_layout.end() && m_firstNonCriticalEntry->m_isCritical)
		m_firstNonCriticalEntry++;
}

//! Makes a copy of the data passed in \a inData.
void St3600IPL::setUserData(const uint8_t * inData, unsigned int inDataLength)
{
	m_userData = new uint8_t[inDataLength];
	m_userDataLength = inDataLength;
	memcpy(m_userData, inData, inDataLength);
}

//! Any padding that is necessary due to the alignment is filled with zeroes.
//!
//! \param alignment The alignment, from 1 to 4096. Must be a power of 2.
//!
//! \exception std::invalid_argument Thrown if \a alignment is 0.
void St3600IPL::setUserDataAlignment(unsigned alignment)
{
    if (alignment == 0)
    {
        throw std::invalid_argument("alignment");
    }
    
    m_userDataAlignment = alignment;
}

//! Load or fill commands are added for each of the memory regions in the
//! executable image. Then, if \a inJump is true, a jump command is added to
//! jump to the image's entry point. If \a inReturn is true then a jump and
//! return command is used instead. An entry point of 0 is acceptable, so
//! as long as \a inJump is true a jump command will always be added. But of course,
//! if the image doesn't have an entry point, then a jump command will not be
//! added.
//!
//! The \a inCritical argument identifies the executable image as critical
//! or not. It is safe to add executable images in random order of criticality.
//! They will still come out grouped correctly, and individual commands from
//! each executable image will stay together.
void St3600IPL::addExecutableImage(const StExecutableImage & inImage, bool inCritical, bool inJump, bool inReturn, uint32_t inJumpArg)
{
	// add commands for each region
	unsigned count = inImage.getRegionCount();
	unsigned i;
	for (i=0; i < count; ++i)
	{
		const StExecutableImage::MemoryRegion & region = inImage.getRegionAtIndex(i);
		
		switch (region.m_type)
		{
			case StExecutableImage::FILL_REGION:
				// we use a 4-byte pattern so it will be as fast as possible. the requirements
				// guarantee it will still work for leading and trailing unaligned bytes.
				addPatternFillCommand(inCritical, region.m_address, region.m_length, 0, 4);
				break;
			
			case StExecutableImage::TEXT_REGION:
				addLoadDataBlockCommand(inCritical, region.m_address, region.m_data, region.m_length);
				break;
		}
	}
	
	// jump to the entry point
	if (inJump && !inImage.hasEntryPoint())
	{
		std::string msg("jump command requested but image '");
		msg += inImage.getName();
		msg += "' has no entry point";
		throw std::runtime_error(msg);
	}
	
	if (inImage.hasEntryPoint() && inJump)
	{
		uint32_t address = inImage.getEntryPoint();
		
		if (inReturn)
			addJumpAndReturnCommand(inCritical, address, inJumpArg);
		else
			addJumpCommand(inCritical, address, inJumpArg);
	}
}

void St3600IPL::fixUpSectionTags()
{
	uint32_t sectionLength = 0;
	LayoutEntry * lastSectionTag = NULL;
	LayoutEntryList::iterator it;
	for (it = m_layout.begin(); it != m_layout.end(); ++it)
	{
		LayoutEntry & thisCommand = *it;
		
		if (thisCommand.m_bootCommand == SECTION_TAG_CMD)
		{
			if (lastSectionTag)
			{
				// Record length of the section into the tag that prefixes it
				// and then reset the length counter to start a new section.
				lastSectionTag->m_destinationAddress = sectionLength;
				sectionLength = 0;
			}
			
			// Remember this new section tag.
			lastSectionTag = &thisCommand;
		}
		else
		{
			// Update length of this section.
			sectionLength += thisCommand.getCommandLengthInBytes();
		}
	}
	
	// Update the last section.
	if (lastSectionTag)
	{
		lastSectionTag->m_destinationAddress = sectionLength;
	}
}

//! \exception std::runtime_error will be thrown if an error occurs while freezing
//!		the image.
void St3600IPL::writeToStream(std::ostream & inStream)
{
	// First thing to do is update section tags with the length of the sections.
	fixUpSectionTags();
	
	// compute total length of commands
	uint32_t commandsLength = 0;
	LayoutEntryList::const_iterator it;
	for (it = m_layout.begin(); it != m_layout.end(); ++it)
	{
		commandsLength += it->getCommandLengthInBytes();
	}
	
	// determine number of blocks needed
	unsigned blockCount = 1;
	
	if (commandsLength > IPL_FIRST_BLOCK_ROOM)
	{
		// round block count up
		blockCount += (((commandsLength - IPL_FIRST_BLOCK_ROOM) - 1) / IPL_OTHER_BLOCK_ROOM) + 1;
	}
	
    unsigned blocksLength = blockCount * IPL_BLOCK_LENGTH;
    unsigned nextAlignment;
    unsigned userDataPaddingLength = 0;
    
    // calculate padding to align user data. padding is only necessary if the
    // required alignment is greater than the block size of 512, since that
    // guarantees a minimum alignment.
    if (m_userData && m_userDataLength > 0 && m_userDataAlignment > IPL_BLOCK_LENGTH)
    {
        nextAlignment = (blocksLength + m_userDataAlignment - 1) / m_userDataAlignment * m_userDataAlignment;
        userDataPaddingLength = nextAlignment - blocksLength;
    }
    
	// fill in the header
	FirstBlockHeader header;
	memset(&header, 0, sizeof(header));
	
	header.m_romVersion = m_romVersion;
	header.m_imageSize = blocksLength + userDataPaddingLength + m_userDataLength;
	header.m_ciphertextOffset = sizeof(header);
	header.m_keyTransformCode = m_keyTransform;
	header.m_productVersion = m_productVersion;
	header.m_componentVersion = m_componentVersion;
	header.m_userDataOffset = m_userData ? blocksLength + userDataPaddingLength : 0;
	header.m_driveTag = m_driveTag;
	
	memcpy(header.m_tag, IPL_HEADER_TAG, IPL_HEADER_TAG_LENGTH);
	
	// output blocks
	WorkingBlock thisBlock;
	CommandOutputState commandState(m_layout);
	unsigned blockNumber = 0;
	for (; blockNumber < blockCount; ++blockNumber)
	{
		// start new block
		thisBlock.reset();
		
		// handle first block
		if (blockNumber == 0)
		{
			if (!thisBlock.writeBytesRequired(&header, sizeof(header)))
			{
				throw std::runtime_error("no room for image header");
			}
			
			// we don't want the header encrypted
			thisBlock.setUnencryptedHeaderLength(sizeof(FirstBlockHeader));
		}
		
		// fill block with bootloader commands
		writeCommandsIntoBlock(thisBlock, commandState);
		
		// encrypt the block. if m_encrypter is null then just the block signature
		// is set to 0.
		thisBlock.encryptAndSign(m_encrypter);
		
		// stream out the finished block
		inStream << thisBlock;
	}
	
	// write the user data, if any
	if (m_userData && m_userDataLength > 0)
	{
        // we've already calculated the padding required to align user data
        if (userDataPaddingLength > 0)
        {
            const unsigned paddingChunkSize = 512;
            unsigned paddingChunks = userDataPaddingLength / paddingChunkSize;
            unsigned paddingResidue = userDataPaddingLength % paddingChunkSize;
            
            char * padding = new char[paddingChunkSize];
            memset(padding, 0, paddingChunkSize);
            
            while (paddingChunks--)
            {
                inStream.write(padding, paddingChunkSize);
            }
            inStream.write(padding, paddingResidue);
            
            delete [] padding;
        }
        
		inStream.write(reinterpret_cast<char *>(m_userData), m_userDataLength);
	}
}

//! Processes commands by writing them into \a ioBlock until either the block is full
//! or there are no more commands remaining. The \a ioCommandState structure is used to
//! keep state information between calls. This is needed because a command may be
//! split across one or more blocks.
//! \exception std::runtime_error is thrown if an error occurs while writing commands
//!		into the block.
void St3600IPL::writeCommandsIntoBlock(WorkingBlock & ioBlock, CommandOutputState & ioState)
{
	while (!ioState.isAtEnd() && !ioBlock.isFull())
	{
		const LayoutEntry & entry = *ioState.m_iterator;
		
		// build command header
		if (!ioState.m_isHeaderBuilt)
		{
			formatCommandHeader(entry, ioState.m_header);
			ioState.m_isHeaderBuilt = true;
		}
		
		// copy as much of the command header into place as possible
		unsigned copyLength;
		if (ioState.m_cursorIndex < sizeof(ioState.m_header))
		{
			unsigned remainingHeader = sizeof(ioState.m_header) - ioState.m_cursorIndex;
			copyLength = ioBlock.writeBytes(&((uint8_t *)(ioState.m_header))[ioState.m_cursorIndex], remainingHeader);
			
			ioState.m_cursorIndex += copyLength;
			ioState.m_remainingBytes -= copyLength;
		}
		
		// copy as much command data into place as possible
		if (!ioBlock.isFull() && ioState.m_remainingBytes > 0 && entry.m_data && entry.m_dataLength > 0)
		{
			unsigned entryDataIndex = ioState.m_cursorIndex - sizeof(ioState.m_header);
			unsigned remainingData = entry.m_dataLength - entryDataIndex;
			copyLength = ioBlock.writeBytes(&entry.m_data[entryDataIndex], remainingData);
			
			ioState.m_cursorIndex += copyLength;
			ioState.m_remainingBytes -= copyLength;
		}
		
		// write any extra pad bytes that are required for the next
		// command to start on a 4-byte boundary.
		if (!ioBlock.isFull() && ioState.m_remainingBytes > 0 && (ioState.m_cursorIndex - sizeof(ioState.m_header)) == entry.m_dataLength)
		{
			// there should never be more than 3 pad bytes.
			if (ioState.m_remainingBytes > 3)
			{
				throw std::runtime_error("too many pad bytes");
			}
			
			const uint8_t zeroes[3] = { 0, 0, 0 };
			ioBlock.writeBytes(zeroes, ioState.m_remainingBytes);
			
			ioState.m_cursorIndex += ioState.m_remainingBytes;
			ioState.m_remainingBytes = 0;
		}
		
		// are we done with this command?
		if (ioState.m_remainingBytes == 0)
		{
			ioState.nextCommand();	// next command
		}
	}
}

//! Takes the fields of the #LayoutEntry \a inEntry and formats them into two 32-bit words.
void St3600IPL::formatCommandHeader(const LayoutEntry & inEntry, uint32_t * ioCommandBytes)
{
	uint32_t word0 = ((inEntry.m_commandLength & 0x7ff) << 21);	// cmd_length[10:0]
	if (inEntry.m_isCritical)
		word0 |= (1 << 20);										// critical[0]
	word0 |= ((inEntry.m_byteCount & 0x3fff) << 6);				// byte_count[13:0]
	word0 |= ((inEntry.m_dataType & 0x3) << 4);					// data_type[1:0]
	word0 |= (inEntry.m_bootCommand & 0xf);						// boot_cmd[3:0]
	
	ioCommandBytes[0] = word0;
	ioCommandBytes[1] = inEntry.m_destinationAddress;
}

void St3600IPL::dumpCommands()
{
	// Update section tag commands before dumping them.
	fixUpSectionTags();
	
	Log::log(Logger::INFO2, "\n%lu commands:\n", m_layout.size());
	
	int commandNum = 0;
	LayoutEntryList::const_iterator it = m_layout.begin();
	for (; it != m_layout.end(); ++it, ++commandNum)
	{
		const LayoutEntry & entry = *it;
		
//		if (it == m_firstNonCriticalEntry)
//			Log::log(Logger::INFO2, "** ");
		
		char *cmdName;
		const char * critical = entry.m_isCritical ? "*" : " ";
		unsigned arg;
		switch (entry.m_bootCommand)
		{
			case LOAD_DATA_BLOCK_CMD:
				cmdName = "LOAD_DATA";
				Log::log(Logger::INFO2, "%05d: %s %20s | addr=0x%08x | len=0x%08x\n", commandNum, critical, cmdName, entry.m_destinationAddress, entry.m_byteCount);
				break;
				
			case PATTERN_FILL_CMD:
				cmdName = "PATTERN_FILL";
				Log::log(Logger::INFO2, "%05d: %s %20s | addr=0x%08x | len=0x%08x | plen=%d\n", commandNum, critical, cmdName, entry.m_destinationAddress, entry.m_byteCount, entry.m_dataLength);
				break;
				
			case BOOTLOADING_COMPLETE_CMD:
				if (entry.m_data)
				{
					arg = *(unsigned *)entry.m_data;
				}
				cmdName = "BOOTLOADING_COMPLETE";
				Log::log(Logger::INFO2, "%05d: %s %20s | addr=0x%08x | arg=0x%08x\n", commandNum, critical, cmdName, entry.m_destinationAddress, arg);
				break;
				
			case JUMP_AND_RETURN_CMD:
				if (entry.m_data)
				{
					arg = *(unsigned *)entry.m_data;
				}
				cmdName = "JUMP_AND_RETURN";
				Log::log(Logger::INFO2, "%05d: %s %20s | addr=0x%08x | arg=0x%08x\n", commandNum, critical, cmdName, entry.m_destinationAddress, arg);
				break;
				
			case SWITCH_DRIVER_CMD:
				cmdName = "SWITCH_DRIVER";
				Log::log(Logger::INFO2, "%05d: %s %20s | addr=0x%08x\n", commandNum, critical, cmdName, entry.m_destinationAddress);
				break;
				
			case SECTION_TAG_CMD:
				cmdName = "SECTION_TAG";
				Log::log(Logger::INFO2, "%05d: %s %20s |  tag=0x%08x | len=0x%08x\n", commandNum, critical, cmdName, entry.m_byteCount, entry.m_destinationAddress);
				break;
				
			default:
				cmdName = "unknown";
				Log::log(Logger::INFO2, "%05d: %s %20s\n", commandNum, critical, cmdName);
		}
	}

	// print info about user data
	if (m_userData)
	{
		Log::log(Logger::INFO2, "User data region: len=0x%08x\n", m_userDataLength);
	}
}

//! Allocates the block and calls reset().
//! \exception std::bad_alloc is thrown if memory for the block cannot be allocated.
St3600IPL::WorkingBlock::WorkingBlock()
:	m_data(0),
	m_free(0),
	m_cursor(0)
{
	m_data = new uint8_t[IPL_BLOCK_LENGTH];
	reset();
}

//! Frees the block data.
St3600IPL::WorkingBlock::~WorkingBlock()
{
	if (m_data)
	{
		delete [] m_data;
	}
}

//! Up to \a inLength bytes of data are written into the block, starting at the current
//! cursor position. If there is less free space than \a inLength, then as many bytes
//! as will fit are written. The number of bytes written are returned. After writing,
//! the cursor is advanced by the number of bytes written, and the free counter is
//! decremented by that amount.
//!
//! \return The number of bytes written into the block. If the block was full, then 0 will
//!		be returned.
//! \sa writeBytesRequired()
unsigned St3600IPL::WorkingBlock::writeBytes(const void * inBytes, unsigned inLength)
{
	if (inBytes == NULL || inLength == 0)
		return 0;
	
	unsigned writeLength = inLength;
	if (m_free < writeLength)
		writeLength = m_free;
	
	memcpy(m_cursor, inBytes, writeLength);
	m_cursor += writeLength;
	m_free -= writeLength;
	
	return writeLength;
}

//! \return A boolean indicating if \a inLength bytes were written into the block. False
//!		indicates that no bytes were written.
//! \sa writeBytes()
bool St3600IPL::WorkingBlock::writeBytesRequired(const void * inBytes, unsigned inLength)
{
	if (inBytes == NULL || inLength == 0)
		return false;
	
	if (m_free < inLength)
		return false;
	
	memcpy(m_cursor, inBytes, inLength);
	m_cursor += inLength;
	m_free -= inLength;
	
	return true;
}

//! The authentication signature is the last 4 bytes of the block. This call
//! does not affect either the cursor or free bytes counter.
void St3600IPL::WorkingBlock::setSignature(uint32_t inSignature)
{
	uint32_t * sig = reinterpret_cast<uint32_t *>(&m_data[IPL_BLOCK_LENGTH - sizeof(uint32_t)]);
	*sig = inSignature;
}

//! Clears the block data to all zeroes. Also sets the cursor to point at the head of
//! the block, and the free bytes counter to the size of the block minus 4 bytes for
//! the authentication signature.
void St3600IPL::WorkingBlock::reset()
{
	m_free = IPL_OTHER_BLOCK_ROOM;
	m_cursor = m_data;
	m_headerLength = 0;
	
	memset(m_data, 0, IPL_BLOCK_LENGTH);
}

void St3600IPL::WorkingBlock::writeToStream(std::ostream & inStream)
{
	inStream.write(reinterpret_cast<char *>(m_data), getLength());
}

//! \param inAlgorithm The encryption algorithm. May be NULL, in which case no actual
//!		encryption is performed, but the signature is explicitly set to 0.
void St3600IPL::WorkingBlock::encryptAndSign(StEncrypter * inAlgorithm)
{
	uint32_t signature = 0;
	if (inAlgorithm)
	{
		// encrypt everything but the signature
		uint8_t * data = m_data + m_headerLength;
		unsigned length = getLength() - sizeof(uint32_t) - m_headerLength;
		signature = inAlgorithm->encryptAndSign(data, length);
	}
	
	// set signature
	setSignature(signature);
}

//! Sets #m_iterator to \a inLayout.begin(), the #m_remainingBytes to the total number
//! of bytes for the first bootloader command, and the other members to 0. If there
//! are no commands in \a inLayout, then #m_remainingBytes is also set to 0.
St3600IPL::CommandOutputState::CommandOutputState(LayoutEntryList & inLayout)
:	m_layout(inLayout),
	m_iterator(inLayout.begin()),
	m_remainingBytes(0),
	m_cursorIndex(0),
	m_isHeaderBuilt(false)
{
	if (m_iterator != inLayout.end())
	{
		m_remainingBytes = m_iterator->getCommandLengthInBytes();
	}
}

//! The iterator is advanced to the next command. If we haven't hit the end of the
//! command list, the #m_cursorIndex is set to 0, #m_remainingBytes is set to the
//! total number of bytes the command will consume in the output image, and
//! #m_isHeaderBuilt is set to false.
void St3600IPL::CommandOutputState::nextCommand()
{
	if (++m_iterator != m_layout.end())
	{
		m_cursorIndex = 0;
		m_remainingBytes = m_iterator->getCommandLengthInBytes();
		m_isHeaderBuilt = false;
	}
}

