/*
 * File:	int_size.h
 *
 * Copyright (c) SigmaTel, Inc. All rights reserved.
 *
 * SigmaTel, Inc.
 * Proprietary & Confidential
 *
 * This source code and the algorithms implemented therein constitute
 * confidential information and may comprise trade secrets of SigmaTel, Inc.
 * or its associates, and any use thereof is subject to the terms and
 * conditions of the Confidential Disclosure Agreement pursual to which this
 * source code was originally received.
 */
#if !defined(_int_size_h_)
#define _int_size_h_

namespace elftosb
{

//! Supported sizes of integers.
typedef enum {
	kWordSize,		//!< 32-bit word.
	kHalfWordSize,	//!< 16-bit half word.
	kByteSize		//!< 8-bit byte.
} int_size_t;

}; // namespace elftosb

#endif // _int_size_h_
