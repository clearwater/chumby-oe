/*
 * File:	StLFSREncrypter.h
 *
 * Copyright (c) SigmaTel, Inc. All rights reserved.
 *
 * SigmaTel, Inc.
 * Proprietary & Confidential
 *
 * This source code and the algorithms implemented therein constitute
 * confidential information and may comprise trade secrets of SigmaTel, Inc.
 * or its associates, and any use thereof is subject to the terms and
 * conditions of the Confidential Disclosure Agreement pursual to which this
 * source code was originally received.
 */

#include "StLFSREncrypter.h"
#include <stdexcept>
#include "crypto.h"

StLFSREncrypter::StLFSREncrypter(const StKeySet & inKeySet)
:	m_keys(inKeySet)
{
}

StLFSREncrypter::~StLFSREncrypter()
{
}

//! The length must be divisible by 4. If not, an exception will be raised.
//! \exception std::invalid_argument Thrown when \a inLength is not divisible by 4.
uint32_t StLFSREncrypter::encryptAndSign(uint8_t * inData, unsigned inLength)
{
	// check length
	if (inLength % 4 != 0)
		throw std::invalid_argument("length not divisible by 4");
	
	return CRYPTO_EncryptBlock(m_keys, reinterpret_cast<uint32_t *>(inData), inLength / 4);
}

//! The length must be divisible by 4. If not, an exception will be raised.
//! \exception std::invalid_argument Thrown when \a inLength is not divisible by 4.
bool StLFSREncrypter::decryptAndAuthenticate(uint8_t * inData, unsigned inLength, uint32_t inSignature)
{
	if (inLength % 4 != 0)
		throw std::invalid_argument("length not divisible by 4");
		
	return CRYPTO_DecryptAndAuthenticateBlock(m_keys, reinterpret_cast<uint32_t *>(inData), inLength / 4, inSignature);
}
