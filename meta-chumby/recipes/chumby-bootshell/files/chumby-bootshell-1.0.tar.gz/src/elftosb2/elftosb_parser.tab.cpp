/* A Bison parser, made by GNU Bison 2.1.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Written by Richard Stallman by simplifying the original so called
   ``semantic'' parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.1"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 1

/* Using locations.  */
#define YYLSP_NEEDED 1



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TOK_IDENT = 258,
     TOK_STRING_LITERAL = 259,
     TOK_INT_LITERAL = 260,
     TOK_SECTION_NAME = 261,
     TOK_SOURCE_NAME = 262,
     TOK_BLOB = 263,
     TOK_DOT_DOT = 264,
     TOK_AND = 265,
     TOK_OR = 266,
     TOK_GEQ = 267,
     TOK_LEQ = 268,
     TOK_EQ = 269,
     TOK_NEQ = 270,
     TOK_POWER = 271,
     TOK_LSHIFT = 272,
     TOK_RSHIFT = 273,
     TOK_INT_SIZE = 274,
     TOK_OPTIONS = 275,
     TOK_CONSTANTS = 276,
     TOK_SOURCES = 277,
     TOK_FILTERS = 278,
     TOK_SECTION = 279,
     TOK_EXTERN = 280,
     TOK_FROM = 281,
     TOK_RAW = 282,
     TOK_LOAD = 283,
     TOK_JUMP = 284,
     TOK_CALL = 285,
     TOK_MODE = 286,
     TOK_IF = 287,
     TOK_ELSE = 288,
     TOK_DEFINED = 289,
     TOK_INFO = 290,
     TOK_WARNING = 291,
     TOK_ERROR = 292,
     TOK_SIZEOF = 293,
     UNARY_OP = 294
   };
#endif
/* Tokens.  */
#define TOK_IDENT 258
#define TOK_STRING_LITERAL 259
#define TOK_INT_LITERAL 260
#define TOK_SECTION_NAME 261
#define TOK_SOURCE_NAME 262
#define TOK_BLOB 263
#define TOK_DOT_DOT 264
#define TOK_AND 265
#define TOK_OR 266
#define TOK_GEQ 267
#define TOK_LEQ 268
#define TOK_EQ 269
#define TOK_NEQ 270
#define TOK_POWER 271
#define TOK_LSHIFT 272
#define TOK_RSHIFT 273
#define TOK_INT_SIZE 274
#define TOK_OPTIONS 275
#define TOK_CONSTANTS 276
#define TOK_SOURCES 277
#define TOK_FILTERS 278
#define TOK_SECTION 279
#define TOK_EXTERN 280
#define TOK_FROM 281
#define TOK_RAW 282
#define TOK_LOAD 283
#define TOK_JUMP 284
#define TOK_CALL 285
#define TOK_MODE 286
#define TOK_IF 287
#define TOK_ELSE 288
#define TOK_DEFINED 289
#define TOK_INFO 290
#define TOK_WARNING 291
#define TOK_ERROR 292
#define TOK_SIZEOF 293
#define UNARY_OP 294




/* Copy the first part of user declarations.  */
#line 14 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"

#include "ElftosbLexer.h"
#include "ElftosbAST.h"
#include "Logging.h"
#include "Blob.h"
#include "format_string.h"
#include "Value.h"

using namespace elftosb;

//! Our special location type.
#define YYLTYPE token_loc_t

// this indicates that we're using our own type. it should be unset automatically
// but that's not working for some reason with the .hpp file.
#if defined(YYLTYPE_IS_TRIVIAL)
	#undef YYLTYPE_IS_TRIVIAL
	#define YYLTYPE_IS_TRIVIAL 0
#endif

//! Default location action
#define YYLLOC_DEFAULT(Current, Rhs, N)	\
	do {		\
		if (N)	\
		{		\
			(Current).m_firstLine = YYRHSLOC(Rhs, 1).m_firstLine;	\
			(Current).m_lastLine = YYRHSLOC(Rhs, N).m_lastLine;		\
		}		\
		else	\
		{		\
			(Current).m_firstLine = (Current).m_lastLine = YYRHSLOC(Rhs, 0).m_lastLine;	\
		}		\
	} while (0)

//! Forward declaration of yylex().
static int yylex(YYSTYPE * lvalp, YYLTYPE * yylloc, ElftosbLexer * lexer);

// Forward declaration of error handling function.
static void yyerror(YYLTYPE * yylloc, ElftosbLexer * lexer, CommandFileASTNode ** resultAST, const char * error);



/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 1
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 57 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
typedef union YYSTYPE {
	int m_num;
	elftosb::SizedIntegerValue * m_int;
	Blob * m_blob;
	string * m_str;
	elftosb::ASTNode * m_ast;	// must use full name here because this is put into *.tab.hpp
} YYSTYPE;
/* Line 196 of yacc.c.  */
#line 213 "/Volumes/VIEWS/projects/elftosb/build/elftosb.build/Debug/elftosb.build/DerivedSources/elftosb_parser.tab.cpp"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

#if ! defined (YYLTYPE) && ! defined (YYLTYPE_IS_DECLARED)
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif


/* Copy the second part of user declarations.  */


/* Line 219 of yacc.c.  */
#line 237 "/Volumes/VIEWS/projects/elftosb/build/elftosb.build/Debug/elftosb.build/DerivedSources/elftosb_parser.tab.cpp"

#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T) && (defined (__STDC__) || defined (__cplusplus))
# include <stddef.h> /* INFRINGES ON USER NAME SPACE */
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

#if ! defined (yyoverflow) || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if defined (__STDC__) || defined (__cplusplus)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     define YYINCLUDED_STDLIB_H
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2005 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM ((YYSIZE_T) -1)
#  endif
#  ifdef __cplusplus
extern "C" {
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if (! defined (malloc) && ! defined (YYINCLUDED_STDLIB_H) \
	&& (defined (__STDC__) || defined (__cplusplus)))
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if (! defined (free) && ! defined (YYINCLUDED_STDLIB_H) \
	&& (defined (__STDC__) || defined (__cplusplus)))
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifdef __cplusplus
}
#  endif
# endif
#endif /* ! defined (yyoverflow) || YYERROR_VERBOSE */


#if (! defined (yyoverflow) \
     && (! defined (__cplusplus) \
	 || (defined (YYLTYPE_IS_TRIVIAL) && YYLTYPE_IS_TRIVIAL \
             && defined (YYSTYPE_IS_TRIVIAL) && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short int yyss;
  YYSTYPE yyvs;
    YYLTYPE yyls;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short int) + sizeof (YYSTYPE) + sizeof (YYLTYPE))	\
      + 2 * YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined (__GNUC__) && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif

#if defined (__STDC__) || defined (__cplusplus)
   typedef signed char yysigned_char;
#else
   typedef short int yysigned_char;
#endif

/* YYFINAL -- State number of the termination state. */
#define YYFINAL  13
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   427

/* YYNTOKENS -- Number of terminals. */
#define YYNTOKENS  63
/* YYNNTS -- Number of nonterminals. */
#define YYNNTS  53
/* YYNRULES -- Number of rules. */
#define YYNRULES  131
/* YYNRULES -- Number of states. */
#define YYNSTATES  231

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   294

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const unsigned char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    26,     2,     2,     2,    61,    23,     2,
       9,    10,    59,    57,    16,    58,    20,    60,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    18,    17,
      25,    15,    19,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    13,     2,    14,    56,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    11,    24,    12,    22,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,    21,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    62
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const unsigned short int yyprhs[] =
{
       0,     0,     3,     6,     8,    11,    13,    15,    17,    22,
      27,    29,    32,    35,    36,    40,    45,    47,    50,    54,
      55,    59,    66,    70,    71,    73,    77,    81,    83,    86,
      93,    96,    97,    99,   100,   105,   109,   111,   112,   116,
     118,   122,   124,   126,   128,   131,   134,   136,   138,   139,
     141,   144,   147,   149,   150,   152,   154,   156,   158,   162,
     164,   166,   168,   170,   174,   176,   178,   182,   184,   187,
     190,   191,   193,   195,   199,   201,   203,   205,   207,   211,
     214,   215,   221,   224,   227,   230,   233,   240,   245,   248,
     249,   251,   255,   257,   259,   261,   265,   269,   273,   277,
     281,   285,   289,   293,   296,   301,   305,   310,   312,   316,
     319,   321,   323,   325,   329,   333,   337,   341,   345,   349,
     353,   357,   361,   365,   369,   371,   375,   379,   384,   389,
     392,   395
};

/* YYRHS -- A `-1'-separated list of the rules' RHS. */
static const yysigned_char yyrhs[] =
{
      64,     0,    -1,    65,    79,    -1,    66,    -1,    65,    66,
      -1,    67,    -1,    68,    -1,    72,    -1,    37,    11,    69,
      12,    -1,    38,    11,    69,    12,    -1,    70,    -1,    69,
      70,    -1,    71,    17,    -1,    -1,     3,    15,   109,    -1,
      39,    11,    73,    12,    -1,    74,    -1,    73,    74,    -1,
      75,    76,    17,    -1,    -1,     3,    15,     4,    -1,     3,
      15,    42,     9,   111,    10,    -1,     9,    77,    10,    -1,
      -1,    78,    -1,    77,    16,    78,    -1,     3,    15,   109,
      -1,    80,    -1,    79,    80,    -1,    41,     9,   111,    81,
      10,    83,    -1,    17,    82,    -1,    -1,    77,    -1,    -1,
      30,     7,    84,    17,    -1,    11,    88,    12,    -1,    85,
      -1,    -1,    13,    86,    14,    -1,    87,    -1,    86,    16,
      87,    -1,   108,    -1,    96,    -1,    89,    -1,    88,    89,
      -1,    92,    17,    -1,   103,    -1,   106,    -1,    -1,    91,
      -1,    90,    91,    -1,    92,    17,    -1,   106,    -1,    -1,
      93,    -1,    99,    -1,   104,    -1,   105,    -1,    45,    94,
      97,    -1,   111,    -1,     4,    -1,     7,    -1,    95,    -1,
      95,    43,     7,    -1,     8,    -1,    96,    -1,    95,    16,
      96,    -1,     6,    -1,    22,     6,    -1,    19,    98,    -1,
      -1,    20,    -1,   108,    -1,   100,   101,   102,    -1,    47,
      -1,    46,    -1,     7,    -1,   111,    -1,     9,   111,    10,
      -1,     9,    10,    -1,    -1,    43,     7,    11,    90,    12,
      -1,    48,   111,    -1,    52,     4,    -1,    53,     4,    -1,
      54,     4,    -1,    49,   110,    11,    88,    12,   107,    -1,
      50,    11,    88,    12,    -1,    50,   106,    -1,    -1,   111,
      -1,   111,    21,   111,    -1,   110,    -1,     4,    -1,   111,
      -1,   110,    25,   110,    -1,   110,    19,   110,    -1,   110,
      29,   110,    -1,   110,    30,   110,    -1,   110,    31,   110,
      -1,   110,    32,   110,    -1,   110,    27,   110,    -1,   110,
      28,   110,    -1,    26,   110,    -1,     3,     9,     7,    10,
      -1,     9,   110,    10,    -1,    51,     9,     3,    10,    -1,
     113,    -1,     7,    18,     3,    -1,    18,     3,    -1,   115,
      -1,     3,    -1,   112,    -1,   113,    57,   113,    -1,   113,
      58,   113,    -1,   113,    59,   113,    -1,   113,    60,   113,
      -1,   113,    61,   113,    -1,   113,    33,   113,    -1,   113,
      23,   113,    -1,   113,    24,   113,    -1,   113,    56,   113,
      -1,   113,    34,   113,    -1,   113,    35,   113,    -1,   114,
      -1,   113,    20,    36,    -1,     9,   113,    10,    -1,    55,
       9,   112,    10,    -1,    55,     9,     3,    10,    -1,    57,
     113,    -1,    58,   113,    -1,     5,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const unsigned short int yyrline[] =
{
       0,   159,   159,   169,   175,   183,   184,   185,   188,   194,
     200,   206,   213,   214,   217,   224,   230,   236,   244,   256,
     259,   264,   272,   273,   277,   283,   291,   298,   304,   311,
     326,   331,   337,   342,   348,   358,   367,   372,   378,   385,
     391,   398,   402,   408,   414,   422,   423,   424,   425,   428,
     434,   442,   443,   444,   447,   448,   449,   450,   453,   466,
     470,   475,   480,   485,   490,   497,   503,   511,   516,   523,
     528,   534,   539,   545,   571,   572,   575,   580,   587,   588,
     589,   592,   599,   606,   611,   616,   623,   634,   638,   645,
     648,   653,   660,   664,   671,   675,   682,   689,   696,   703,
     710,   717,   724,   731,   736,   741,   746,   753,   756,   761,
     769,   773,   778,   789,   796,   803,   810,   817,   824,   831,
     838,   845,   852,   859,   866,   870,   875,   880,   885,   892,
     896,   903
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals. */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "\"identifier\"", "\"string\"",
  "\"integer\"", "\"section name\"", "\"source name\"",
  "\"binary object\"", "'('", "')'", "'{'", "'}'", "'['", "']'", "'='",
  "','", "';'", "':'", "'>'", "'.'", "\"..\"", "'~'", "'&'", "'|'", "'<'",
  "'!'", "\"&&\"", "\"||\"", "\">=\"", "\"<=\"", "\"==\"", "\"!=\"",
  "\"**\"", "\"<<\"", "\">>\"", "\"integer size\"", "\"options\"",
  "\"constants\"", "\"sources\"", "\"filters\"", "\"section\"",
  "\"extern\"", "\"from\"", "\"raw\"", "\"load\"", "\"jump\"", "\"call\"",
  "\"mode\"", "\"if\"", "\"else\"", "\"defined\"", "\"info\"",
  "\"warning\"", "\"error\"", "\"sizeof\"", "'^'", "'+'", "'-'", "'*'",
  "'/'", "'%'", "UNARY_OP", "$accept", "command_file", "blocks_list",
  "pre_section_block", "options_block", "constants_block",
  "const_def_list", "const_def_list_elem", "const_def", "sources_block",
  "source_def_list", "source_def_list_elem", "source_def",
  "source_attrs_opt", "source_attr_list", "source_attr_list_elem",
  "section_defs", "section_def", "section_options_opt",
  "source_attr_list_opt", "section_contents", "data_section_slice_opt",
  "data_section_slice", "slice_list", "slice_list_elem", "full_stmt_list",
  "full_stmt_list_elem", "basic_stmt_list", "basic_stmt_list_elem",
  "basic_stmt", "load_stmt", "load_data", "section_list",
  "section_list_elem", "load_target_opt", "load_target", "call_stmt",
  "call_or_jump", "call_target", "call_arg_opt", "from_stmt", "mode_stmt",
  "message_stmt", "if_stmt", "else_opt", "address_or_range", "const_expr",
  "bool_expr", "int_const_expr", "symbol_ref", "expr", "unary_expr",
  "int_value", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const unsigned short int yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,    40,
      41,   123,   125,    91,    93,    61,    44,    59,    58,    62,
      46,   264,   126,    38,   124,    60,    33,   265,   266,   267,
     268,   269,   270,   271,   272,   273,   274,   275,   276,   277,
     278,   279,   280,   281,   282,   283,   284,   285,   286,   287,
     288,   289,   290,   291,   292,   293,    94,    43,    45,    42,
      47,    37,   294
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const unsigned char yyr1[] =
{
       0,    63,    64,    65,    65,    66,    66,    66,    67,    68,
      69,    69,    70,    70,    71,    72,    73,    73,    74,    74,
      75,    75,    76,    76,    77,    77,    78,    79,    79,    80,
      81,    81,    82,    82,    83,    83,    84,    84,    85,    86,
      86,    87,    87,    88,    88,    89,    89,    89,    89,    90,
      90,    91,    91,    91,    92,    92,    92,    92,    93,    94,
      94,    94,    94,    94,    94,    95,    95,    96,    96,    97,
      97,    98,    98,    99,   100,   100,   101,   101,   102,   102,
     102,   103,   104,   105,   105,   105,   106,   107,   107,   107,
     108,   108,   109,   109,   110,   110,   110,   110,   110,   110,
     110,   110,   110,   110,   110,   110,   110,   111,   112,   112,
     113,   113,   113,   113,   113,   113,   113,   113,   113,   113,
     113,   113,   113,   113,   113,   113,   113,   113,   113,   114,
     114,   115
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const unsigned char yyr2[] =
{
       0,     2,     2,     1,     2,     1,     1,     1,     4,     4,
       1,     2,     2,     0,     3,     4,     1,     2,     3,     0,
       3,     6,     3,     0,     1,     3,     3,     1,     2,     6,
       2,     0,     1,     0,     4,     3,     1,     0,     3,     1,
       3,     1,     1,     1,     2,     2,     1,     1,     0,     1,
       2,     2,     1,     0,     1,     1,     1,     1,     3,     1,
       1,     1,     1,     3,     1,     1,     3,     1,     2,     2,
       0,     1,     1,     3,     1,     1,     1,     1,     3,     2,
       0,     5,     2,     2,     2,     2,     6,     4,     2,     0,
       1,     3,     1,     1,     1,     3,     3,     3,     3,     3,
       3,     3,     3,     2,     4,     3,     4,     1,     3,     2,
       1,     1,     1,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     1,     3,     3,     4,     4,     2,
       2,     1
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const unsigned char yydefact[] =
{
       0,     0,     0,     0,     0,     0,     3,     5,     6,     7,
      13,    13,    19,     1,     0,     4,     2,    27,     0,     0,
      10,     0,     0,     0,     0,    16,    23,     0,    28,     0,
       8,    11,    12,     9,     0,    15,    17,     0,     0,   111,
     131,     0,     0,     0,     0,     0,     0,    31,   112,   107,
     124,   110,   111,    93,     0,     0,     0,    14,    92,    94,
      20,     0,     0,     0,    24,    18,     0,     0,   109,     0,
     129,   130,    33,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   107,   103,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    22,     0,   108,   126,     0,     0,    32,    30,     0,
     125,   119,   120,   118,   122,   123,   121,   113,   114,   115,
     116,   117,     0,   105,     0,    96,    95,   101,   102,    97,
      98,    99,   100,     0,    26,    25,   128,   127,    48,     0,
      29,   104,   106,    21,     0,     0,    75,    74,     0,     0,
       0,     0,     0,     0,    43,     0,    54,    55,     0,    46,
      56,    57,    47,    37,     0,    60,    67,    61,    64,     0,
      70,    62,    65,    59,    82,     0,    83,    84,    85,    35,
      44,    45,    76,    80,    77,     0,     0,    36,    53,    68,
       0,    58,     0,     0,    48,     0,    73,     0,    39,    42,
      41,    90,    34,     0,    49,     0,    52,    71,    69,    72,
      66,    63,     0,    79,     0,    38,     0,     0,    81,    50,
      51,    89,    78,    40,    91,     0,    86,    48,    88,     0,
      87
};

/* YYDEFGOTO[NTERM-NUM]. */
static const short int yydefgoto[] =
{
      -1,     4,     5,     6,     7,     8,    19,    20,    21,     9,
      24,    25,    26,    38,    63,    64,    16,    17,    73,   108,
     140,   186,   187,   197,   198,   153,   154,   203,   204,   155,
     156,   170,   171,   199,   191,   208,   157,   158,   183,   196,
     159,   160,   161,   162,   226,   200,    57,    58,    59,    48,
      49,    50,    51
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -173
static const short int yypact[] =
{
      90,    15,    18,    46,    76,   272,  -173,  -173,  -173,  -173,
      78,    78,    80,  -173,    82,  -173,    48,  -173,    72,    22,
    -173,    96,   102,    84,   104,  -173,   106,   137,  -173,     9,
    -173,  -173,  -173,  -173,     7,  -173,  -173,   116,   103,  -173,
    -173,   123,   137,   121,   113,   137,   137,   126,  -173,   259,
    -173,  -173,   139,  -173,    43,    43,   141,  -173,   358,  -173,
    -173,   144,   146,    21,  -173,  -173,   159,   149,  -173,    85,
    -173,  -173,   116,   154,   129,   137,   137,   137,   137,   137,
     137,   137,   137,   137,   137,   137,   160,   318,   149,  -173,
     163,    43,    43,    43,    43,    43,    43,    43,    43,   137,
       9,  -173,   116,  -173,  -173,   161,   164,   165,  -173,    17,
    -173,    77,   265,   247,   119,   119,   307,   182,   182,   150,
     150,   150,   176,  -173,   177,  -173,  -173,   372,   372,  -173,
    -173,  -173,  -173,   178,  -173,  -173,  -173,  -173,   362,   168,
    -173,  -173,  -173,  -173,   184,     1,  -173,  -173,   137,    43,
     189,   192,   197,   173,  -173,   187,  -173,  -173,   142,  -173,
    -173,  -173,  -173,   190,   201,  -173,  -173,   123,  -173,   207,
     198,     8,  -173,  -173,  -173,   344,  -173,  -173,  -173,  -173,
    -173,  -173,   123,   219,  -173,    68,   213,  -173,   373,  -173,
      75,  -173,    14,   230,   362,    99,  -173,    49,  -173,  -173,
    -173,   235,  -173,   224,  -173,   245,  -173,  -173,  -173,  -173,
    -173,  -173,   186,  -173,   253,  -173,    68,   137,  -173,  -173,
    -173,   218,  -173,  -173,  -173,     4,  -173,   362,  -173,   212,
    -173
};

/* YYPGOTO[NTERM-NUM].  */
static const short int yypgoto[] =
{
    -173,  -173,  -173,   269,  -173,  -173,   264,    11,  -173,  -173,
    -173,   256,  -173,  -173,   209,   185,  -173,   268,  -173,  -173,
    -173,  -173,  -173,  -173,    70,  -172,  -150,  -173,    86,  -118,
    -173,  -173,  -173,  -124,  -173,  -173,  -173,  -173,  -173,  -173,
    -173,  -173,  -173,  -171,  -173,   100,   191,   -53,   -27,   226,
     169,  -173,  -173
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -1
static const unsigned char yytable[] =
{
      47,    87,    89,   180,    39,   165,    40,   166,   167,   168,
      42,    60,    52,    53,    40,   227,    41,   206,    54,    43,
     166,   172,   212,   169,   192,    18,    10,    43,   138,    11,
      31,   101,   206,    31,    30,    55,   169,   102,   125,   126,
     127,   128,   129,   130,   131,   132,    52,   139,    40,    61,
      41,   193,    54,   149,   228,   229,    44,    12,    45,    46,
      56,    43,   180,   215,    44,   216,    45,    46,   210,    55,
     205,    39,   133,    40,   166,    41,    13,    42,    39,   180,
      40,    18,    41,    23,    42,   205,    43,    29,   105,    14,
     169,    27,    41,    43,    56,   207,   175,    74,    44,    34,
      45,    46,    39,    43,    40,    18,    41,    23,    42,   213,
      77,    78,    79,    32,    33,    37,    35,    43,   173,    62,
      65,   174,    69,    44,    68,    45,    46,     1,     2,     3,
      44,   184,    45,    46,    81,    82,    83,    84,    85,    74,
      39,    66,    40,    72,    41,    39,    42,    40,    86,   182,
      90,    42,    77,    99,    44,    43,    45,    46,   201,   104,
      43,   100,   103,   201,   109,   110,   124,   122,   214,    74,
      74,   136,    75,    76,   137,   163,    81,    82,    83,    84,
      85,   102,    77,    78,    79,   179,   141,   142,   143,   201,
     224,   164,    44,   176,    45,    46,   177,    44,   221,    45,
      46,   178,    74,   185,   181,    80,    81,    82,    83,    84,
      85,    67,   188,   189,    70,    71,   144,   190,   145,   146,
     147,   148,   149,    88,   230,   150,   151,   152,   195,   144,
     202,   145,   146,   147,   148,   149,   218,   211,   150,   151,
     152,    83,    84,    85,   111,   112,   113,   114,   115,   116,
     117,   118,   119,   120,   121,   144,   217,   145,   146,   147,
     148,   149,   220,   222,   150,   151,   152,    74,   225,   145,
     146,   147,   148,   149,    15,    22,   150,   151,   152,    74,
      36,   107,    75,    76,    28,    74,   223,   135,    75,   219,
     209,   134,    77,    78,    79,   106,     0,     0,    77,    78,
      79,     0,     0,     0,    81,    82,    83,    84,    85,     1,
       2,     3,     0,    14,     0,    80,    81,    82,    83,    84,
      85,    80,    81,    82,    83,    84,    85,    74,   123,     0,
      75,     0,     0,     0,     0,     0,     0,    91,     0,     0,
      77,    78,    79,    92,     0,    93,    94,    95,    96,    97,
      98,     0,     0,     0,     0,   194,     0,     0,     0,     0,
       0,     0,     0,    91,    81,    82,    83,    84,    85,    92,
       0,    93,    94,    95,    96,    97,    98,    91,     0,     0,
       0,     0,     0,    92,     0,    93,    94,    95,    96,    97,
      98,    91,     0,     0,     0,     0,     0,    92,     0,     0,
       0,    95,    96,    97,    98,   144,     0,   145,   146,   147,
     148,   149,     0,     0,   150,   151,   152,     0,   145,   146,
     147,   148,   149,     0,     0,   150,   151,   152
};

static const short int yycheck[] =
{
      27,    54,    55,   153,     3,     4,     5,     6,     7,     8,
       9,     4,     3,     4,     5,    11,     7,   188,     9,    18,
       6,   145,   194,    22,    16,     3,    11,    18,    11,    11,
      19,    10,   203,    22,    12,    26,    22,    16,    91,    92,
      93,    94,    95,    96,    97,    98,     3,    30,     5,    42,
       7,    43,     9,    49,   225,   227,    55,    11,    57,    58,
      51,    18,   212,    14,    55,    16,    57,    58,   192,    26,
     188,     3,    99,     5,     6,     7,     0,     9,     3,   229,
       5,     3,     7,     3,     9,   203,    18,    15,     3,    41,
      22,     9,     7,    18,    51,    20,   149,    20,    55,    15,
      57,    58,     3,    18,     5,     3,     7,     3,     9,    10,
      33,    34,    35,    17,    12,     9,    12,    18,   145,     3,
      17,   148,     9,    55,     3,    57,    58,    37,    38,    39,
      55,   158,    57,    58,    57,    58,    59,    60,    61,    20,
       3,    18,     5,    17,     7,     3,     9,     5,     9,     7,
       9,     9,    33,     9,    55,    18,    57,    58,   185,    10,
      18,    15,     3,   190,    10,    36,     3,     7,   195,    20,
      20,    10,    23,    24,    10,     7,    57,    58,    59,    60,
      61,    16,    33,    34,    35,    12,    10,    10,    10,   216,
     217,     7,    55,     4,    57,    58,     4,    55,    12,    57,
      58,     4,    20,    13,    17,    56,    57,    58,    59,    60,
      61,    42,    11,     6,    45,    46,    43,    19,    45,    46,
      47,    48,    49,    54,    12,    52,    53,    54,     9,    43,
      17,    45,    46,    47,    48,    49,    12,     7,    52,    53,
      54,    59,    60,    61,    75,    76,    77,    78,    79,    80,
      81,    82,    83,    84,    85,    43,    21,    45,    46,    47,
      48,    49,    17,    10,    52,    53,    54,    20,    50,    45,
      46,    47,    48,    49,     5,    11,    52,    53,    54,    20,
      24,    72,    23,    24,    16,    20,   216,   102,    23,   203,
     190,   100,    33,    34,    35,    69,    -1,    -1,    33,    34,
      35,    -1,    -1,    -1,    57,    58,    59,    60,    61,    37,
      38,    39,    -1,    41,    -1,    56,    57,    58,    59,    60,
      61,    56,    57,    58,    59,    60,    61,    20,    10,    -1,
      23,    -1,    -1,    -1,    -1,    -1,    -1,    19,    -1,    -1,
      33,    34,    35,    25,    -1,    27,    28,    29,    30,    31,
      32,    -1,    -1,    -1,    -1,    11,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    19,    57,    58,    59,    60,    61,    25,
      -1,    27,    28,    29,    30,    31,    32,    19,    -1,    -1,
      -1,    -1,    -1,    25,    -1,    27,    28,    29,    30,    31,
      32,    19,    -1,    -1,    -1,    -1,    -1,    25,    -1,    -1,
      -1,    29,    30,    31,    32,    43,    -1,    45,    46,    47,
      48,    49,    -1,    -1,    52,    53,    54,    -1,    45,    46,
      47,    48,    49,    -1,    -1,    52,    53,    54
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const unsigned char yystos[] =
{
       0,    37,    38,    39,    64,    65,    66,    67,    68,    72,
      11,    11,    11,     0,    41,    66,    79,    80,     3,    69,
      70,    71,    69,     3,    73,    74,    75,     9,    80,    15,
      12,    70,    17,    12,    15,    12,    74,     9,    76,     3,
       5,     7,     9,    18,    55,    57,    58,   111,   112,   113,
     114,   115,     3,     4,     9,    26,    51,   109,   110,   111,
       4,    42,     3,    77,    78,    17,    18,   113,     3,     9,
     113,   113,    17,    81,    20,    23,    24,    33,    34,    35,
      56,    57,    58,    59,    60,    61,     9,   110,   113,   110,
       9,    19,    25,    27,    28,    29,    30,    31,    32,     9,
      15,    10,    16,     3,    10,     3,   112,    77,    82,    10,
      36,   113,   113,   113,   113,   113,   113,   113,   113,   113,
     113,   113,     7,    10,     3,   110,   110,   110,   110,   110,
     110,   110,   110,   111,   109,    78,    10,    10,    11,    30,
      83,    10,    10,    10,    43,    45,    46,    47,    48,    49,
      52,    53,    54,    88,    89,    92,    93,    99,   100,   103,
     104,   105,   106,     7,     7,     4,     6,     7,     8,    22,
      94,    95,    96,   111,   111,   110,     4,     4,     4,    12,
      89,    17,     7,   101,   111,    13,    84,    85,    11,     6,
      19,    97,    16,    43,    11,     9,   102,    86,    87,    96,
     108,   111,    17,    90,    91,    92,   106,    20,    98,   108,
      96,     7,    88,    10,   111,    14,    16,    21,    12,    91,
      17,    12,    10,    87,   111,    50,   107,    11,   106,    88,
      12
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (&yylloc, lexer, resultAST, YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (0)


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (N)								\
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (0)
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
              (Loc).first_line, (Loc).first_column,	\
              (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (&yylval, &yylloc, YYLEX_PARAM)
#else
# define YYLEX yylex (&yylval, &yylloc, lexer)
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)		\
do {								\
  if (yydebug)							\
    {								\
      YYFPRINTF (stderr, "%s ", Title);				\
      yysymprint (stderr,					\
                  Type, Value, Location);	\
      YYFPRINTF (stderr, "\n");					\
    }								\
} while (0)

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_stack_print (short int *bottom, short int *top)
#else
static void
yy_stack_print (bottom, top)
    short int *bottom;
    short int *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (/* Nothing. */; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_reduce_print (int yyrule)
#else
static void
yy_reduce_print (yyrule)
    int yyrule;
#endif
{
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu), ",
             yyrule - 1, yylno);
  /* Print the symbols being reduced, and their result.  */
  for (yyi = yyprhs[yyrule]; 0 <= yyrhs[yyi]; yyi++)
    YYFPRINTF (stderr, "%s ", yytname[yyrhs[yyi]]);
  YYFPRINTF (stderr, "-> %s\n", yytname[yyr1[yyrule]]);
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (Rule);		\
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      size_t yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

#endif /* YYERROR_VERBOSE */



#if YYDEBUG
/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yysymprint (FILE *yyoutput, int yytype, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
#else
static void
yysymprint (yyoutput, yytype, yyvaluep, yylocationp)
    FILE *yyoutput;
    int yytype;
    YYSTYPE *yyvaluep;
    YYLTYPE *yylocationp;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;
  (void) yylocationp;

  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  YY_LOCATION_PRINT (yyoutput, *yylocationp);
  YYFPRINTF (yyoutput, ": ");

# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
  switch (yytype)
    {
      default:
        break;
    }
  YYFPRINTF (yyoutput, ")");
}

#endif /* ! YYDEBUG */
/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
#else
static void
yydestruct (yymsg, yytype, yyvaluep, yylocationp)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
    YYLTYPE *yylocationp;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;
  (void) yylocationp;

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {
      case 3: /* "\"identifier\"" */
#line 155 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
        { delete (yyvaluep->m_str); };
#line 1203 "/Volumes/VIEWS/projects/elftosb/build/elftosb.build/Debug/elftosb.build/DerivedSources/elftosb_parser.tab.cpp"
        break;
      case 4: /* "\"string\"" */
#line 155 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
        { delete (yyvaluep->m_str); };
#line 1208 "/Volumes/VIEWS/projects/elftosb/build/elftosb.build/Debug/elftosb.build/DerivedSources/elftosb_parser.tab.cpp"
        break;
      case 5: /* "\"integer\"" */
#line 155 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
        { delete (yyvaluep->m_int); };
#line 1213 "/Volumes/VIEWS/projects/elftosb/build/elftosb.build/Debug/elftosb.build/DerivedSources/elftosb_parser.tab.cpp"
        break;
      case 6: /* "\"section name\"" */
#line 155 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
        { delete (yyvaluep->m_str); };
#line 1218 "/Volumes/VIEWS/projects/elftosb/build/elftosb.build/Debug/elftosb.build/DerivedSources/elftosb_parser.tab.cpp"
        break;
      case 7: /* "\"source name\"" */
#line 155 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
        { delete (yyvaluep->m_str); };
#line 1223 "/Volumes/VIEWS/projects/elftosb/build/elftosb.build/Debug/elftosb.build/DerivedSources/elftosb_parser.tab.cpp"
        break;
      case 8: /* "\"binary object\"" */
#line 155 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
        { delete (yyvaluep->m_blob); };
#line 1228 "/Volumes/VIEWS/projects/elftosb/build/elftosb.build/Debug/elftosb.build/DerivedSources/elftosb_parser.tab.cpp"
        break;
      case 36: /* "\"integer size\"" */
#line 155 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
        { delete (yyvaluep->m_int); };
#line 1233 "/Volumes/VIEWS/projects/elftosb/build/elftosb.build/Debug/elftosb.build/DerivedSources/elftosb_parser.tab.cpp"
        break;

      default:
        break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM);
# else
int yyparse ();
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int yyparse (ElftosbLexer * lexer, CommandFileASTNode ** resultAST);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */






/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM)
# else
int yyparse (YYPARSE_PARAM)
  void *YYPARSE_PARAM;
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int
yyparse (ElftosbLexer * lexer, CommandFileASTNode ** resultAST)
#else
int
yyparse (lexer, resultAST)
    ElftosbLexer * lexer;
    CommandFileASTNode ** resultAST;
#endif
#endif
{
  /* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;
/* Location data for the look-ahead symbol.  */
YYLTYPE yylloc;

  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  short int yyssa[YYINITDEPTH];
  short int *yyss = yyssa;
  short int *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;

  /* The location stack.  */
  YYLTYPE yylsa[YYINITDEPTH];
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;
  /* The locations where the error started and ended. */
  YYLTYPE yyerror_range[2];

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
  YYLTYPE yyloc;

  /* When reducing, the number of symbols on the RHS of the reduced
     rule.  */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;
  yylsp = yyls;
#if YYLTYPE_IS_TRIVIAL
  /* Initialize the default location before parsing starts.  */
  yylloc.first_line   = yylloc.last_line   = 1;
  yylloc.first_column = yylloc.last_column = 0;
#endif

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short int *yyss1 = yyss;
	YYLTYPE *yyls1 = yyls;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yyls1, yysize * sizeof (*yylsp),
		    &yystacksize);
	yyls = yyls1;
	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	short int *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);
	YYSTACK_RELOCATE (yyls);
#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
      yylsp = yyls + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a look-ahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to look-ahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
  *++yylsp = yylloc;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

  /* Default location. */
  YYLLOC_DEFAULT (yyloc, yylsp - yylen, yylen);
  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 160 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
							CommandFileASTNode * commandFile = new CommandFileASTNode();
							commandFile->setBlocks(dynamic_cast<ListASTNode*>((yyvsp[-1].m_ast)));
							commandFile->setSections(dynamic_cast<ListASTNode*>((yyvsp[0].m_ast)));
							commandFile->setLocation((yylsp[-1]), (yylsp[0]));
							*resultAST = commandFile;
						;}
    break;

  case 3:
#line 170 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
							ListASTNode * list = new ListASTNode();
							list->appendNode((yyvsp[0].m_ast));
							(yyval.m_ast) = list;
						;}
    break;

  case 4:
#line 176 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
							dynamic_cast<ListASTNode*>((yyvsp[-1].m_ast))->appendNode((yyvsp[0].m_ast));
							(yyval.m_ast) = (yyvsp[-1].m_ast);
						;}
    break;

  case 5:
#line 183 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_ast) = (yyvsp[0].m_ast); ;}
    break;

  case 6:
#line 184 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_ast) = (yyvsp[0].m_ast); ;}
    break;

  case 7:
#line 185 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_ast) = (yyvsp[0].m_ast); ;}
    break;

  case 8:
#line 189 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new OptionsBlockASTNode(dynamic_cast<ListASTNode *>((yyvsp[-1].m_ast)));
							;}
    break;

  case 9:
#line 195 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new ConstantsBlockASTNode(dynamic_cast<ListASTNode *>((yyvsp[-1].m_ast)));
							;}
    break;

  case 10:
#line 201 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								ListASTNode * list = new ListASTNode();
								list->appendNode((yyvsp[0].m_ast));
								(yyval.m_ast) = list;
							;}
    break;

  case 11:
#line 207 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								dynamic_cast<ListASTNode*>((yyvsp[-1].m_ast))->appendNode((yyvsp[0].m_ast));
								(yyval.m_ast) = (yyvsp[-1].m_ast);
							;}
    break;

  case 12:
#line 213 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_ast) = (yyvsp[-1].m_ast); ;}
    break;

  case 13:
#line 214 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_ast) = NULL; ;}
    break;

  case 14:
#line 218 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new AssignmentASTNode((yyvsp[-2].m_str), (yyvsp[0].m_ast));
								(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
							;}
    break;

  case 15:
#line 225 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
							(yyval.m_ast) = new SourcesBlockASTNode(dynamic_cast<ListASTNode *>((yyvsp[-1].m_ast)));
						;}
    break;

  case 16:
#line 231 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
							ListASTNode * list = new ListASTNode();
							list->appendNode((yyvsp[0].m_ast));
							(yyval.m_ast) = list;
						;}
    break;

  case 17:
#line 237 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
							dynamic_cast<ListASTNode*>((yyvsp[-1].m_ast))->appendNode((yyvsp[0].m_ast));
							(yyval.m_ast) = (yyvsp[-1].m_ast);
						;}
    break;

  case 18:
#line 245 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								// tell the lexer that this is the name of a source file
								SourceDefASTNode * node = dynamic_cast<SourceDefASTNode*>((yyvsp[-2].m_ast));
								if ((yyvsp[-1].m_ast))
								{
									node->setAttributes(dynamic_cast<ListASTNode*>((yyvsp[-1].m_ast)));
								}
								node->setLocation(node->getLocation(), (yylsp[0]));
								lexer->addSourceName(node->getName());
								(yyval.m_ast) = (yyvsp[-2].m_ast);
							;}
    break;

  case 19:
#line 256 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_ast) = NULL; ;}
    break;

  case 20:
#line 260 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new PathSourceDefASTNode((yyvsp[-2].m_str), (yyvsp[0].m_str));
								(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
							;}
    break;

  case 21:
#line 265 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new ExternSourceDefASTNode((yyvsp[-5].m_str), dynamic_cast<ExprASTNode*>((yyvsp[-1].m_ast)));
								(yyval.m_ast)->setLocation((yylsp[-5]), (yylsp[0]));
							;}
    break;

  case 22:
#line 272 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_ast) = (yyvsp[-1].m_ast); ;}
    break;

  case 23:
#line 273 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_ast) = NULL; ;}
    break;

  case 24:
#line 278 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								ListASTNode * list = new ListASTNode();
								list->appendNode((yyvsp[0].m_ast));
								(yyval.m_ast) = list;
							;}
    break;

  case 25:
#line 284 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								dynamic_cast<ListASTNode*>((yyvsp[-2].m_ast))->appendNode((yyvsp[0].m_ast));
								(yyval.m_ast) = (yyvsp[-2].m_ast);
							;}
    break;

  case 26:
#line 292 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new AssignmentASTNode((yyvsp[-2].m_str), (yyvsp[0].m_ast));
								(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
							;}
    break;

  case 27:
#line 299 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								ListASTNode * list = new ListASTNode();
								list->appendNode((yyvsp[0].m_ast));
								(yyval.m_ast) = list;
							;}
    break;

  case 28:
#line 305 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								dynamic_cast<ListASTNode*>((yyvsp[-1].m_ast))->appendNode((yyvsp[0].m_ast));
								(yyval.m_ast) = (yyvsp[-1].m_ast);
							;}
    break;

  case 29:
#line 312 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								SectionContentsASTNode * sectionNode = dynamic_cast<SectionContentsASTNode*>((yyvsp[0].m_ast));
								if (sectionNode)
								{
									ExprASTNode * exprNode = dynamic_cast<ExprASTNode*>((yyvsp[-3].m_ast));
									sectionNode->setSectionNumberExpr(exprNode);
									sectionNode->setOptions(dynamic_cast<ListASTNode*>((yyvsp[-2].m_ast)));
									sectionNode->setLocation((yylsp[-5]), sectionNode->getLocation());
								}
								(yyval.m_ast) = (yyvsp[0].m_ast);
							;}
    break;

  case 30:
#line 327 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = (yyvsp[0].m_ast);
							;}
    break;

  case 31:
#line 331 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = NULL;
							;}
    break;

  case 32:
#line 338 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = (yyvsp[0].m_ast);
							;}
    break;

  case 33:
#line 342 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = NULL;
							;}
    break;

  case 34:
#line 349 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								DataSectionContentsASTNode * dataSection = new DataSectionContentsASTNode((yyvsp[-2].m_str));
								if ((yyvsp[-1].m_ast) && dynamic_cast<ListASTNode*>((yyvsp[-1].m_ast)))
								{
									dataSection->setSliceList(dynamic_cast<ListASTNode*>((yyvsp[-1].m_ast)));
								}
								dataSection->setLocation((yylsp[-3]), (yylsp[0]));
								(yyval.m_ast) = dataSection;
							;}
    break;

  case 35:
#line 359 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								ListASTNode * listNode = dynamic_cast<ListASTNode*>((yyvsp[-1].m_ast));
								(yyval.m_ast) = new BootableSectionContentsASTNode(listNode);
								(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
							;}
    break;

  case 36:
#line 368 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = (yyvsp[0].m_ast);
							;}
    break;

  case 37:
#line 372 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = NULL;
							;}
    break;

  case 38:
#line 379 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = (yyvsp[-1].m_ast);
								(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
							;}
    break;

  case 39:
#line 386 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								ListASTNode * list = new ListASTNode();
								list->appendNode((yyvsp[0].m_ast));
								(yyval.m_ast) = list;
							;}
    break;

  case 40:
#line 392 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								dynamic_cast<ListASTNode*>((yyvsp[-2].m_ast))->appendNode((yyvsp[0].m_ast));
								(yyval.m_ast) = (yyvsp[-2].m_ast);
							;}
    break;

  case 41:
#line 399 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = (yyvsp[0].m_ast);
							;}
    break;

  case 42:
#line 403 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = (yyvsp[0].m_ast);
							;}
    break;

  case 43:
#line 409 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								ListASTNode * list = new ListASTNode();
								list->appendNode((yyvsp[0].m_ast));
								(yyval.m_ast) = list;
							;}
    break;

  case 44:
#line 415 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								dynamic_cast<ListASTNode*>((yyvsp[-1].m_ast))->appendNode((yyvsp[0].m_ast));
								(yyval.m_ast) = (yyvsp[-1].m_ast);
							;}
    break;

  case 45:
#line 422 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_ast) = (yyvsp[-1].m_ast); ;}
    break;

  case 46:
#line 423 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_ast) = (yyvsp[0].m_ast); ;}
    break;

  case 47:
#line 424 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_ast) = (yyvsp[0].m_ast); ;}
    break;

  case 48:
#line 425 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_ast) = NULL; ;}
    break;

  case 49:
#line 429 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								ListASTNode * list = new ListASTNode();
								list->appendNode((yyvsp[0].m_ast));
								(yyval.m_ast) = list;
							;}
    break;

  case 50:
#line 435 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								dynamic_cast<ListASTNode*>((yyvsp[-1].m_ast))->appendNode((yyvsp[0].m_ast));
								(yyval.m_ast) = (yyvsp[-1].m_ast);
							;}
    break;

  case 51:
#line 442 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_ast) = (yyvsp[-1].m_ast); ;}
    break;

  case 52:
#line 443 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_ast) = (yyvsp[0].m_ast); ;}
    break;

  case 53:
#line 444 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_ast) = NULL; ;}
    break;

  case 54:
#line 447 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_ast) = (yyvsp[0].m_ast); ;}
    break;

  case 55:
#line 448 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_ast) = (yyvsp[0].m_ast); ;}
    break;

  case 56:
#line 449 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_ast) = (yyvsp[0].m_ast); ;}
    break;

  case 57:
#line 450 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_ast) = (yyvsp[0].m_ast); ;}
    break;

  case 58:
#line 454 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								LoadStatementASTNode * stmt = new LoadStatementASTNode();
								stmt->setData((yyvsp[-1].m_ast));
								stmt->setTarget((yyvsp[0].m_ast));
								if ((yyvsp[0].m_ast))
									stmt->setLocation((yylsp[-2]), (yylsp[0]));
								else
									stmt->setLocation((yylsp[-2]), (yylsp[-1]));
								(yyval.m_ast) = stmt;
							;}
    break;

  case 59:
#line 467 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = (yyvsp[0].m_ast);
							;}
    break;

  case 60:
#line 471 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new StringConstASTNode((yyvsp[0].m_str));
								(yyval.m_ast)->setLocation((yylsp[0]));
							;}
    break;

  case 61:
#line 476 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new SourceASTNode((yyvsp[0].m_str));
								(yyval.m_ast)->setLocation((yylsp[0]));
							;}
    break;

  case 62:
#line 481 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new SectionMatchListASTNode(dynamic_cast<ListASTNode*>((yyvsp[0].m_ast)));
								(yyval.m_ast)->setLocation((yylsp[0]));
							;}
    break;

  case 63:
#line 486 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new SectionMatchListASTNode(dynamic_cast<ListASTNode*>((yyvsp[-2].m_ast)), (yyvsp[0].m_str));
								(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
							;}
    break;

  case 64:
#line 491 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new BlobConstASTNode((yyvsp[0].m_blob));
								(yyval.m_ast)->setLocation((yylsp[0]));
							;}
    break;

  case 65:
#line 498 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								ListASTNode * list = new ListASTNode();
								list->appendNode((yyvsp[0].m_ast));
								(yyval.m_ast) = list;
							;}
    break;

  case 66:
#line 504 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								dynamic_cast<ListASTNode*>((yyvsp[-2].m_ast))->appendNode((yyvsp[0].m_ast));
								(yyval.m_ast) = (yyvsp[-2].m_ast);
							;}
    break;

  case 67:
#line 512 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new SectionASTNode((yyvsp[0].m_str), SectionASTNode::kInclude);
								(yyval.m_ast)->setLocation((yylsp[0]));
							;}
    break;

  case 68:
#line 517 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new SectionASTNode((yyvsp[0].m_str), SectionASTNode::kExclude);
								(yyval.m_ast)->setLocation((yylsp[-1]), (yylsp[0]));
							;}
    break;

  case 69:
#line 524 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = (yyvsp[0].m_ast);
							;}
    break;

  case 70:
#line 528 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new NaturalLocationASTNode();
//								$$->setLocation();
							;}
    break;

  case 71:
#line 535 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new NaturalLocationASTNode();
								(yyval.m_ast)->setLocation((yylsp[0]));
							;}
    break;

  case 72:
#line 540 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = (yyvsp[0].m_ast);
							;}
    break;

  case 73:
#line 546 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								CallStatementASTNode * stmt = new CallStatementASTNode();
								switch ((yyvsp[-2].m_num))
								{
									case 1:
										stmt->setCallType(CallStatementASTNode::kCallType);
										break;
									case 2:
										stmt->setCallType(CallStatementASTNode::kJumpType);
										break;
									default:
										yyerror(&yylloc, lexer, resultAST, "invalid call_or_jump value");
										YYABORT;
										break;
								}
								stmt->setTarget((yyvsp[-1].m_ast));
								stmt->setArgument((yyvsp[0].m_ast));
								if ((yyvsp[0].m_ast))
									stmt->setLocation((yylsp[-2]), (yylsp[0]));
								else
									stmt->setLocation((yylsp[-2]), (yylsp[-1]));
								(yyval.m_ast) = stmt;
							;}
    break;

  case 74:
#line 571 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_num) = 1; ;}
    break;

  case 75:
#line 572 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_num) = 2; ;}
    break;

  case 76:
#line 576 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new SymbolASTNode(NULL, (yyvsp[0].m_str));
								(yyval.m_ast)->setLocation((yylsp[0]));
							;}
    break;

  case 77:
#line 581 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new AddressRangeASTNode((yyvsp[0].m_ast), NULL);
								(yyval.m_ast)->setLocation((yyvsp[0].m_ast));
							;}
    break;

  case 78:
#line 587 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_ast) = (yyvsp[-1].m_ast); ;}
    break;

  case 79:
#line 588 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_ast) = NULL; ;}
    break;

  case 80:
#line 589 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_ast) = NULL; ;}
    break;

  case 81:
#line 593 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new FromStatementASTNode((yyvsp[-3].m_str), dynamic_cast<ListASTNode*>((yyvsp[-1].m_ast)));
								(yyval.m_ast)->setLocation((yylsp[-4]), (yylsp[0]));
							;}
    break;

  case 82:
#line 600 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new ModeStatementASTNode(dynamic_cast<ExprASTNode*>((yyvsp[0].m_ast)));
								(yyval.m_ast)->setLocation((yylsp[-1]), (yylsp[0]));
							;}
    break;

  case 83:
#line 607 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new MessageStatementASTNode(MessageStatementASTNode::kInfo, (yyvsp[0].m_str));
								(yyval.m_ast)->setLocation((yylsp[-1]), (yylsp[0]));
							;}
    break;

  case 84:
#line 612 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new MessageStatementASTNode(MessageStatementASTNode::kWarning, (yyvsp[0].m_str));
								(yyval.m_ast)->setLocation((yylsp[-1]), (yylsp[0]));
							;}
    break;

  case 85:
#line 617 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new MessageStatementASTNode(MessageStatementASTNode::kError, (yyvsp[0].m_str));
								(yyval.m_ast)->setLocation((yylsp[-1]), (yylsp[0]));
							;}
    break;

  case 86:
#line 624 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								IfStatementASTNode * ifStmt = new IfStatementASTNode();
								ifStmt->setConditionExpr(dynamic_cast<ExprASTNode*>((yyvsp[-4].m_ast)));
								ifStmt->setIfStatements(dynamic_cast<ListASTNode*>((yyvsp[-2].m_ast)));
								ifStmt->setElseStatements(dynamic_cast<ListASTNode*>((yyvsp[0].m_ast)));
								ifStmt->setLocation((yylsp[-5]), (yylsp[0]));
								(yyval.m_ast) = ifStmt;
							;}
    break;

  case 87:
#line 635 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = (yyvsp[-1].m_ast);
							;}
    break;

  case 88:
#line 639 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								ListASTNode * list = new ListASTNode();
								list->appendNode((yyvsp[0].m_ast));
								(yyval.m_ast) = list;
								(yyval.m_ast)->setLocation((yylsp[-1]), (yylsp[0]));
							;}
    break;

  case 89:
#line 645 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_ast) = NULL; ;}
    break;

  case 90:
#line 649 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new AddressRangeASTNode((yyvsp[0].m_ast), NULL);
								(yyval.m_ast)->setLocation((yyvsp[0].m_ast));
							;}
    break;

  case 91:
#line 654 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new AddressRangeASTNode((yyvsp[-2].m_ast), (yyvsp[0].m_ast));
								(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
							;}
    break;

  case 92:
#line 661 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = (yyvsp[0].m_ast);
							;}
    break;

  case 93:
#line 665 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new StringConstASTNode((yyvsp[0].m_str));
								(yyval.m_ast)->setLocation((yylsp[0]));
							;}
    break;

  case 94:
#line 672 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
							(yyval.m_ast) = (yyvsp[0].m_ast);
						;}
    break;

  case 95:
#line 676 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
							ExprASTNode * left = dynamic_cast<ExprASTNode*>((yyvsp[-2].m_ast));
							ExprASTNode * right = dynamic_cast<ExprASTNode*>((yyvsp[0].m_ast));
							(yyval.m_ast) = new BinaryOpExprASTNode(left, BinaryOpExprASTNode::kLessThan, right);
							(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
						;}
    break;

  case 96:
#line 683 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
							ExprASTNode * left = dynamic_cast<ExprASTNode*>((yyvsp[-2].m_ast));
							ExprASTNode * right = dynamic_cast<ExprASTNode*>((yyvsp[0].m_ast));
							(yyval.m_ast) = new BinaryOpExprASTNode(left, BinaryOpExprASTNode::kGreaterThan, right);
							(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
						;}
    break;

  case 97:
#line 690 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
							ExprASTNode * left = dynamic_cast<ExprASTNode*>((yyvsp[-2].m_ast));
							ExprASTNode * right = dynamic_cast<ExprASTNode*>((yyvsp[0].m_ast));
							(yyval.m_ast) = new BinaryOpExprASTNode(left, BinaryOpExprASTNode::kGreaterThanEqual, right);
							(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
						;}
    break;

  case 98:
#line 697 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
							ExprASTNode * left = dynamic_cast<ExprASTNode*>((yyvsp[-2].m_ast));
							ExprASTNode * right = dynamic_cast<ExprASTNode*>((yyvsp[0].m_ast));
							(yyval.m_ast) = new BinaryOpExprASTNode(left, BinaryOpExprASTNode::kLessThanEqual, right);
							(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
						;}
    break;

  case 99:
#line 704 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
							ExprASTNode * left = dynamic_cast<ExprASTNode*>((yyvsp[-2].m_ast));
							ExprASTNode * right = dynamic_cast<ExprASTNode*>((yyvsp[0].m_ast));
							(yyval.m_ast) = new BinaryOpExprASTNode(left, BinaryOpExprASTNode::kEqual, right);
							(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
						;}
    break;

  case 100:
#line 711 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
							ExprASTNode * left = dynamic_cast<ExprASTNode*>((yyvsp[-2].m_ast));
							ExprASTNode * right = dynamic_cast<ExprASTNode*>((yyvsp[0].m_ast));
							(yyval.m_ast) = new BinaryOpExprASTNode(left, BinaryOpExprASTNode::kNotEqual, right);
							(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
						;}
    break;

  case 101:
#line 718 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
							ExprASTNode * left = dynamic_cast<ExprASTNode*>((yyvsp[-2].m_ast));
							ExprASTNode * right = dynamic_cast<ExprASTNode*>((yyvsp[0].m_ast));
							(yyval.m_ast) = new BinaryOpExprASTNode(left, BinaryOpExprASTNode::kBooleanAnd, right);
							(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
						;}
    break;

  case 102:
#line 725 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
							ExprASTNode * left = dynamic_cast<ExprASTNode*>((yyvsp[-2].m_ast));
							ExprASTNode * right = dynamic_cast<ExprASTNode*>((yyvsp[0].m_ast));
							(yyval.m_ast) = new BinaryOpExprASTNode(left, BinaryOpExprASTNode::kBooleanOr, right);
							(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
						;}
    break;

  case 103:
#line 732 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
							(yyval.m_ast) = new BooleanNotExprASTNode(dynamic_cast<ExprASTNode*>((yyvsp[0].m_ast)));
							(yyval.m_ast)->setLocation((yylsp[-1]), (yylsp[0]));
						;}
    break;

  case 104:
#line 737 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
							(yyval.m_ast) = new SourceFileFunctionASTNode((yyvsp[-3].m_str), (yyvsp[-1].m_str));
							(yyval.m_ast)->setLocation((yylsp[-3]), (yylsp[0]));
						;}
    break;

  case 105:
#line 742 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
							(yyval.m_ast) = (yyvsp[-1].m_ast);
							(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
						;}
    break;

  case 106:
#line 747 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
							(yyval.m_ast) = new DefinedOperatorASTNode((yyvsp[-1].m_str));
							(yyval.m_ast)->setLocation((yylsp[-3]), (yylsp[0]));
						;}
    break;

  case 107:
#line 753 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    { (yyval.m_ast) = (yyvsp[0].m_ast); ;}
    break;

  case 108:
#line 757 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new SymbolASTNode((yyvsp[0].m_str), (yyvsp[-2].m_str));
								(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
							;}
    break;

  case 109:
#line 762 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new SymbolASTNode((yyvsp[0].m_str));
								(yyval.m_ast)->setLocation((yylsp[-1]), (yylsp[0]));
							;}
    break;

  case 110:
#line 770 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = (yyvsp[0].m_ast);
							;}
    break;

  case 111:
#line 774 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new VariableExprASTNode((yyvsp[0].m_str));
								(yyval.m_ast)->setLocation((yylsp[0]));
							;}
    break;

  case 112:
#line 779 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new SymbolRefExprASTNode(dynamic_cast<SymbolASTNode*>((yyvsp[0].m_ast)));
								(yyval.m_ast)->setLocation((yylsp[0]));
							;}
    break;

  case 113:
#line 790 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								ExprASTNode * left = dynamic_cast<ExprASTNode*>((yyvsp[-2].m_ast));
								ExprASTNode * right = dynamic_cast<ExprASTNode*>((yyvsp[0].m_ast));
								(yyval.m_ast) = new BinaryOpExprASTNode(left, BinaryOpExprASTNode::kAdd, right);
								(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
							;}
    break;

  case 114:
#line 797 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								ExprASTNode * left = dynamic_cast<ExprASTNode*>((yyvsp[-2].m_ast));
								ExprASTNode * right = dynamic_cast<ExprASTNode*>((yyvsp[0].m_ast));
								(yyval.m_ast) = new BinaryOpExprASTNode(left, BinaryOpExprASTNode::kSubtract, right);
								(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
							;}
    break;

  case 115:
#line 804 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								ExprASTNode * left = dynamic_cast<ExprASTNode*>((yyvsp[-2].m_ast));
								ExprASTNode * right = dynamic_cast<ExprASTNode*>((yyvsp[0].m_ast));
								(yyval.m_ast) = new BinaryOpExprASTNode(left, BinaryOpExprASTNode::kMultiply, right);
								(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
							;}
    break;

  case 116:
#line 811 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								ExprASTNode * left = dynamic_cast<ExprASTNode*>((yyvsp[-2].m_ast));
								ExprASTNode * right = dynamic_cast<ExprASTNode*>((yyvsp[0].m_ast));
								(yyval.m_ast) = new BinaryOpExprASTNode(left, BinaryOpExprASTNode::kDivide, right);
								(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
							;}
    break;

  case 117:
#line 818 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								ExprASTNode * left = dynamic_cast<ExprASTNode*>((yyvsp[-2].m_ast));
								ExprASTNode * right = dynamic_cast<ExprASTNode*>((yyvsp[0].m_ast));
								(yyval.m_ast) = new BinaryOpExprASTNode(left, BinaryOpExprASTNode::kModulus, right);
								(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
							;}
    break;

  case 118:
#line 825 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								ExprASTNode * left = dynamic_cast<ExprASTNode*>((yyvsp[-2].m_ast));
								ExprASTNode * right = dynamic_cast<ExprASTNode*>((yyvsp[0].m_ast));
								(yyval.m_ast) = new BinaryOpExprASTNode(left, BinaryOpExprASTNode::kPower, right);
								(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
							;}
    break;

  case 119:
#line 832 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								ExprASTNode * left = dynamic_cast<ExprASTNode*>((yyvsp[-2].m_ast));
								ExprASTNode * right = dynamic_cast<ExprASTNode*>((yyvsp[0].m_ast));
								(yyval.m_ast) = new BinaryOpExprASTNode(left, BinaryOpExprASTNode::kBitwiseAnd, right);
								(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
							;}
    break;

  case 120:
#line 839 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								ExprASTNode * left = dynamic_cast<ExprASTNode*>((yyvsp[-2].m_ast));
								ExprASTNode * right = dynamic_cast<ExprASTNode*>((yyvsp[0].m_ast));
								(yyval.m_ast) = new BinaryOpExprASTNode(left, BinaryOpExprASTNode::kBitwiseOr, right);
								(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
							;}
    break;

  case 121:
#line 846 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								ExprASTNode * left = dynamic_cast<ExprASTNode*>((yyvsp[-2].m_ast));
								ExprASTNode * right = dynamic_cast<ExprASTNode*>((yyvsp[0].m_ast));
								(yyval.m_ast) = new BinaryOpExprASTNode(left, BinaryOpExprASTNode::kBitwiseXor, right);
								(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
							;}
    break;

  case 122:
#line 853 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								ExprASTNode * left = dynamic_cast<ExprASTNode*>((yyvsp[-2].m_ast));
								ExprASTNode * right = dynamic_cast<ExprASTNode*>((yyvsp[0].m_ast));
								(yyval.m_ast) = new BinaryOpExprASTNode(left, BinaryOpExprASTNode::kShiftLeft, right);
								(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
							;}
    break;

  case 123:
#line 860 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								ExprASTNode * left = dynamic_cast<ExprASTNode*>((yyvsp[-2].m_ast));
								ExprASTNode * right = dynamic_cast<ExprASTNode*>((yyvsp[0].m_ast));
								(yyval.m_ast) = new BinaryOpExprASTNode(left, BinaryOpExprASTNode::kShiftRight, right);
								(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
							;}
    break;

  case 124:
#line 867 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = (yyvsp[0].m_ast);
							;}
    break;

  case 125:
#line 871 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new IntSizeExprASTNode(dynamic_cast<ExprASTNode*>((yyvsp[-2].m_ast)), (yyvsp[0].m_int)->getWordSize());
								(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
							;}
    break;

  case 126:
#line 876 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = (yyvsp[-1].m_ast);
								(yyval.m_ast)->setLocation((yylsp[-2]), (yylsp[0]));
							;}
    break;

  case 127:
#line 881 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
							(yyval.m_ast) = new SizeofOperatorASTNode(dynamic_cast<SymbolASTNode*>((yyvsp[-1].m_ast)));
							(yyval.m_ast)->setLocation((yylsp[-3]), (yylsp[0]));
						;}
    break;

  case 128:
#line 886 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
							(yyval.m_ast) = new SizeofOperatorASTNode((yyvsp[-1].m_str));
							(yyval.m_ast)->setLocation((yylsp[-3]), (yylsp[0]));
						;}
    break;

  case 129:
#line 893 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = (yyvsp[0].m_ast);
							;}
    break;

  case 130:
#line 897 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new NegativeExprASTNode(dynamic_cast<ExprASTNode*>((yyvsp[0].m_ast)));
								(yyval.m_ast)->setLocation((yylsp[-1]), (yylsp[0]));
							;}
    break;

  case 131:
#line 904 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"
    {
								(yyval.m_ast) = new IntConstExprASTNode((yyvsp[0].m_int)->getValue(), (yyvsp[0].m_int)->getWordSize());
								(yyval.m_ast)->setLocation((yylsp[0]));
							;}
    break;


      default: break;
    }

/* Line 1126 of yacc.c.  */
#line 2598 "/Volumes/VIEWS/projects/elftosb/build/elftosb.build/Debug/elftosb.build/DerivedSources/elftosb_parser.tab.cpp"

  yyvsp -= yylen;
  yyssp -= yylen;
  yylsp -= yylen;

  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;
  *++yylsp = yyloc;

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (YYPACT_NINF < yyn && yyn < YYLAST)
	{
	  int yytype = YYTRANSLATE (yychar);
	  YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
	  YYSIZE_T yysize = yysize0;
	  YYSIZE_T yysize1;
	  int yysize_overflow = 0;
	  char *yymsg = 0;
#	  define YYERROR_VERBOSE_ARGS_MAXIMUM 5
	  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
	  int yyx;

#if 0
	  /* This is so xgettext sees the translatable formats that are
	     constructed on the fly.  */
	  YY_("syntax error, unexpected %s");
	  YY_("syntax error, unexpected %s, expecting %s");
	  YY_("syntax error, unexpected %s, expecting %s or %s");
	  YY_("syntax error, unexpected %s, expecting %s or %s or %s");
	  YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
#endif
	  char *yyfmt;
	  char const *yyf;
	  static char const yyunexpected[] = "syntax error, unexpected %s";
	  static char const yyexpecting[] = ", expecting %s";
	  static char const yyor[] = " or %s";
	  char yyformat[sizeof yyunexpected
			+ sizeof yyexpecting - 1
			+ ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
			   * (sizeof yyor - 1))];
	  char const *yyprefix = yyexpecting;

	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  int yyxbegin = yyn < 0 ? -yyn : 0;

	  /* Stay within bounds of both yycheck and yytname.  */
	  int yychecklim = YYLAST - yyn;
	  int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
	  int yycount = 1;

	  yyarg[0] = yytname[yytype];
	  yyfmt = yystpcpy (yyformat, yyunexpected);

	  for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	      {
		if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
		  {
		    yycount = 1;
		    yysize = yysize0;
		    yyformat[sizeof yyunexpected - 1] = '\0';
		    break;
		  }
		yyarg[yycount++] = yytname[yyx];
		yysize1 = yysize + yytnamerr (0, yytname[yyx]);
		yysize_overflow |= yysize1 < yysize;
		yysize = yysize1;
		yyfmt = yystpcpy (yyfmt, yyprefix);
		yyprefix = yyor;
	      }

	  yyf = YY_(yyformat);
	  yysize1 = yysize + yystrlen (yyf);
	  yysize_overflow |= yysize1 < yysize;
	  yysize = yysize1;

	  if (!yysize_overflow && yysize <= YYSTACK_ALLOC_MAXIMUM)
	    yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg)
	    {
	      /* Avoid sprintf, as that infringes on the user's name space.
		 Don't have undefined behavior even if the translation
		 produced a string with the wrong number of "%s"s.  */
	      char *yyp = yymsg;
	      int yyi = 0;
	      while ((*yyp = *yyf))
		{
		  if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		    {
		      yyp += yytnamerr (yyp, yyarg[yyi++]);
		      yyf += 2;
		    }
		  else
		    {
		      yyp++;
		      yyf++;
		    }
		}
	      yyerror (&yylloc, lexer, resultAST, yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    {
	      yyerror (&yylloc, lexer, resultAST, YY_("syntax error"));
	      goto yyexhaustedlab;
	    }
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror (&yylloc, lexer, resultAST, YY_("syntax error"));
    }

  yyerror_range[0] = yylloc;

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
        {
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
        }
      else
	{
	  yydestruct ("Error: discarding", yytoken, &yylval, &yylloc);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (0)
     goto yyerrorlab;

  yyerror_range[0] = yylsp[1-yylen];
  yylsp -= yylen;
  yyvsp -= yylen;
  yyssp -= yylen;
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;

      yyerror_range[0] = *yylsp;
      yydestruct ("Error: popping", yystos[yystate], yyvsp, yylsp);
      YYPOPSTACK;
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;

  yyerror_range[1] = yylloc;
  /* Using YYLLOC is tempting, but would change the location of
     the look-ahead.  YYLOC is available though. */
  YYLLOC_DEFAULT (yyloc, yyerror_range - 1, 2);
  *++yylsp = yyloc;

  /* Shift the error token. */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (&yylloc, lexer, resultAST, YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval, &yylloc);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp, yylsp);
      YYPOPSTACK;
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}


#line 910 "/Volumes/VIEWS/projects/elftosb/elftosb2/elftosb_parser.y"


/* code goes here */

static int yylex(YYSTYPE * lvalp, YYLTYPE * yylloc, ElftosbLexer * lexer)
{
	int token = lexer->yylex();
	*yylloc = lexer->getLocation();
	lexer->getSymbolValue(lvalp);
	return token;
}

static void yyerror(YYLTYPE * yylloc, ElftosbLexer * lexer, CommandFileASTNode ** resultAST, const char * error)
{
	throw syntax_error(format_string("line %d: %s\n", yylloc->m_firstLine, error));
}


