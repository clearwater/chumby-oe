/*
 * File:	StKeySet.h
 *
 * Copyright (c) SigmaTel, Inc. All rights reserved.
 *
 * SigmaTel, Inc.
 * Proprietary & Confidential
 *
 * This source code and the algorithms implemented therein constitute
 * confidential information and may comprise trade secrets of SigmaTel, Inc.
 * or its associates, and any use thereof is subject to the terms and
 * conditions of the Confidential Disclosure Agreement pursual to which this
 * source code was originally received.
 */
#if !defined(_StKeySet_h_)
#define _StKeySet_h_

#include "stdafx.h"
#include "crypto.h"
#include <iostream>

/*!
 * \brief Manages a key set, including loading from a file.
 */
class StKeySet
{
public:
	//! \brief Default constructor.
	StKeySet();
    
    //! \brief Constructor taking a pointer to the key data.
    StKeySet(const unsigned char * keyData);
	
	//! \brief Alternate constructor.
	StKeySet(key_set_t & inKeys);
	
	//! \brief Copy constructor.
	StKeySet(const StKeySet & inOther);
	
	//! \brief Destructor.
	virtual ~StKeySet();
	
	//! \brief Read key set from an input stream.
	virtual void readFromStream(std::istream & inStream);
	
	//! \brief Modify the keys in-place based on a 32-bit transform value.
	virtual void transform(uint32_t inTransformCode, uint32_t inSpinSteps);
	
	//! \name Key access
	//! These methods provide access to the raw key data.
	//@{
	inline key_set_t * getMutableKeys() { return &m_keys; }
	inline const key_set_t * getKeys() const { return &m_keys; }
	
	inline operator key_set_t * () { return &m_keys; }
	inline operator const key_set_t * () const { return &m_keys; }
	//@}
	
	//! \brief Assignment operator.
	StKeySet & operator = (const StKeySet & inOther);
	
protected:
	key_set_t m_keys;	//!< The key set.
};

#endif // _StKeySet_h_
