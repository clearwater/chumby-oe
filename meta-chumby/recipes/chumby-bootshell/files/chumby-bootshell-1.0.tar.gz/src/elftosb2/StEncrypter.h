/*
 * File:	StEncrypter.h
 *
 * Copyright (c) SigmaTel, Inc. All rights reserved.
 *
 * SigmaTel, Inc.
 * Proprietary & Confidential
 *
 * This source code and the algorithms implemented therein constitute
 * confidential information and may comprise trade secrets of SigmaTel, Inc.
 * or its associates, and any use thereof is subject to the terms and
 * conditions of the Confidential Disclosure Agreement pursual to which this
 * source code was originally received.
 */
#if !defined(_StEncrypter_h_)
#define _StEncrypter_h_

#include "stdafx.h"

/*!
 * \brief Abstract base class for an encryption algorithm.
 */
class StEncrypter
{
public:
	StEncrypter() {}
	virtual ~StEncrypter() {}
	
	//! \brief Encrypts the data in-place and returns the signature.
	virtual uint32_t encryptAndSign(uint8_t * inData, unsigned inLength)=0;
	
	//! \brief Decrypt \a inData in-place and return whether not it matches \a inSignature.
	virtual bool decryptAndAuthenticate(uint8_t * inData, unsigned inLength, uint32_t inSignature)=0;
};

#endif // _StEncrypter_h_
